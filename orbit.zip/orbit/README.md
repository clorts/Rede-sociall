# Orbit — rede social

JavaScript puro + Supabase + Capacitor (APK). Mesma estrutura do City Exchange.

## Como usar
1. Crie um projeto no Supabase, abra **SQL Editor** e rode `supabase/001_orbit.sql`.
2. `src/config.js` já aponta para o seu projeto Supabase.
3. Em Authentication, desligue "Confirm email" para testar rápido.
4. Teste no PC: `npm run dev` (abre em http://localhost:5173).
5. Netlify: suba a pasta no GitHub e conecte (já tem `netlify.toml`). APK: o GitHub Actions (`apk.yml`) gera sozinho.

## Pastas
- `src/` telas (feed, chat, perfil, busca, auth, splash)
- `supabase/` banco, regras e notificações
- `native/` ícones e chave do Android · `scripts/` ajuste do Android

## Regras de comentário
Quem comenta pode apagar só o seu; o dono da publicação apaga qualquer um e aparece com o selo **Autor**.

## Ainda não incluído
Ligações de voz/vídeo com toque e notificação push com o app fechado (precisam de WebRTC e Firebase). Notificações já funcionam com o app aberto.
