import { supabase } from "./supabase.js";
import { h } from "./ui.js";
export function authScreen(done, notice = "") {
  let signup = false; const box = h("div", { class: "center" });
  const draw = () => {
    const name = h("input", { placeholder: "Seu nome" }), user = h("input", { placeholder: "@usuario" }), mail = h("input", { type: "email", placeholder: "E-mail" }), pass = h("input", { type: "password", placeholder: "Senha (mín. 6)" }), msg = h("p", { class: "mut" }, notice);
    const send = async () => {
      msg.textContent = "Aguarde...";
      const r = signup ? await supabase.auth.signUp({ email: mail.value.trim(), password: pass.value, options: { data: { name: name.value.trim(), username: user.value.trim().replace("@", "") } } }) : await supabase.auth.signInWithPassword({ email: mail.value.trim(), password: pass.value });
      if (r.error) msg.textContent = r.error.message; else if (!r.data.session) msg.textContent = "Confirme seu e-mail e entre."; else done();
    };
    box.replaceChildren(h("img", { class: "sp-logo", src: "/src/assets/icon.png" }), h("h1", {}, "Orbit"), signup && name, signup && user, mail, pass, msg,
      h("button", { class: "btn", onclick: send }, signup ? "Criar conta" : "Entrar"),
      h("p", { class: "mut", style: "margin-top:14px", onclick: () => { signup = !signup; draw(); } }, signup ? "Já tenho conta" : "Criar uma conta"));
  };
  draw(); return h("div", { style: "padding:30px 10px" }, box);
}
