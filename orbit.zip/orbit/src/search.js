import { supabase } from "./supabase.js";
import { h, go, avatar } from "./ui.js";
export function searchScreen(view) {
  const out = h("div"); let t;
  const input = h("input", { placeholder: "Pesquisar pessoas...", oninput: () => { clearTimeout(t); t = setTimeout(async () => {
    const q = input.value.trim().replace(/[%,]/g, ""); if (q.length < 2) return out.replaceChildren();
    const { data } = await supabase.from("ob_profiles").select("*").or(`name.ilike.%${q}%,username.ilike.%${q}%`).limit(30);
    out.replaceChildren(...(data?.length ? data.map((u) => h("div", { class: "row", onclick: () => go("/user/" + u.id) }, avatar(u, 44), h("div", {}, h("b", {}, u.name), h("div", { class: "mut" }, "@" + u.username)))) : [h("p", { class: "mut center" }, "Ninguém encontrado.")]));
  }, 300); } });
  view.append(h("h2", {}, "Pesquisar"), input, out);
}
