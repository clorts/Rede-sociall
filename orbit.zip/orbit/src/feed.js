import { supabase } from "./supabase.js";
import { S, getProfile } from "./state.js";
import { h, go, ago, avatar, media, pick, upload, toast } from "./ui.js";

const SEL = "*, author:ob_profiles(id,name,username,avatar), likes:ob_likes(count), comms:ob_comments(count)";

export async function postCard(p, mine = new Set()) {
  let liked = mine.has(p.id), n = p.likes?.[0]?.count || 0;
  const lb = h("button", { class: liked ? "on" : "" }); const paint = () => { lb.textContent = (liked ? "♥ " : "♡ ") + n; lb.className = liked ? "on" : ""; }; paint();
  lb.onclick = async () => {
    liked = !liked; n += liked ? 1 : -1; paint();
    if (liked) await supabase.from("ob_likes").insert({ post_id: p.id, user_id: S.user.id });
    else await supabase.from("ob_likes").delete().match({ post_id: p.id, user_id: S.user.id });
  };
  return h("div", { class: "card" },
    h("div", { class: "hd", onclick: () => go("/user/" + p.user_id) }, avatar(p.author), h("div", {}, h("b", {}, p.author?.name), h("div", { class: "mut" }, "@" + p.author?.username + " · " + ago(p.created_at)))),
    media(p.kind, p.url), p.caption && h("p", {}, p.caption),
    h("div", { class: "ft" }, lb, h("button", { onclick: () => go("/post/" + p.id) }, "💬 " + (p.comms?.[0]?.count || 0)), h("button", { onclick: () => sharePost(p) }, "➤ Enviar")));
}

async function sharePost(p) {
  const { data } = await supabase.from("ob_follows").select("following:ob_profiles!ob_follows_following_fkey(id,name,username,avatar)").eq("follower", S.user.id);
  const list = (data || []).map((x) => x.following);
  const box = h("div", { style: "position:fixed;inset:0;background:#000a;z-index:50;display:flex;align-items:flex-end" },
    h("div", { class: "card", style: "width:100%;max-width:560px;margin:auto;padding:12px;max-height:60vh;overflow:auto" }, h("b", {}, "Enviar para um amigo"),
      list.length ? list.map((u) => h("div", { class: "row", onclick: async () => { await supabase.from("ob_messages").insert({ from_id: S.user.id, to_id: u.id, kind: "post", post_id: p.id }); box.remove(); toast("Enviado para " + u.name); } }, avatar(u), u.name)) : h("p", { class: "mut" }, "Siga alguém para poder enviar."),
      h("button", { class: "btn ghost sm", onclick: () => box.remove() }, "Fechar")));
  document.body.append(box);
}

export async function feedScreen(view) {
  view.append(h("h2", {}, "Orbit"), h("p", { class: "mut" }, "Carregando..."));
  const { data: fl } = await supabase.from("ob_follows").select("following").eq("follower", S.user.id);
  const ids = [S.user.id, ...(fl || []).map((x) => x.following)];
  let { data: posts } = await supabase.from("ob_posts").select(SEL).in("user_id", ids).order("created_at", { ascending: false }).limit(40);
  if (!posts?.length || posts.length < 3) posts = (await supabase.from("ob_posts").select(SEL).order("created_at", { ascending: false }).limit(40)).data;
  const { data: lk } = await supabase.from("ob_likes").select("post_id").eq("user_id", S.user.id);
  const mine = new Set((lk || []).map((x) => x.post_id));
  view.replaceChildren(h("h2", {}, "Orbit"), ...(posts?.length ? await Promise.all(posts.map((p) => postCard(p, mine))) : [h("p", { class: "mut center" }, "Nada por aqui ainda. Poste a primeira foto!")]));
}

export function newPostScreen(view) {
  let file = null; const prev = h("div"), cap = h("textarea", { placeholder: "Legenda...", rows: 3 }), msg = h("p", { class: "mut" });
  view.append(h("h2", {}, "Nova publicação"), prev, h("button", { class: "btn ghost", onclick: () => pick("image/*,video/*", (f) => { file = f; prev.replaceChildren(media(f.type.startsWith("video") ? "video" : "image", URL.createObjectURL(f))); }) }, "Escolher foto ou vídeo"), cap, msg,
    h("button", { class: "btn", onclick: async () => {
      if (!file) return (msg.textContent = "Escolha uma foto ou vídeo.");
      try { msg.textContent = "Enviando..."; const url = await upload(file, S.user.id); await supabase.from("ob_posts").insert({ user_id: S.user.id, kind: file.type.startsWith("video") ? "video" : "image", url, caption: cap.value.trim() }); go("/feed"); } catch (e) { msg.textContent = e.message; }
    } }, "Publicar"));
}

export async function postScreen(view, id) {
  const { data: p } = await supabase.from("ob_posts").select(SEL).eq("id", id).maybeSingle();
  if (!p) return view.append(h("p", { class: "center" }, "Publicação não encontrada."));
  const { data: lk } = await supabase.from("ob_likes").select("post_id").eq("user_id", S.user.id).eq("post_id", id);
  const list = h("div"), isOwner = p.user_id === S.user.id;
  const load = async () => {
    const { data } = await supabase.from("ob_comments").select("*").eq("post_id", id).order("created_at");
    list.replaceChildren(...await Promise.all((data || []).map(async (c) => {
      const u = await getProfile(c.user_id);
      return h("div", { class: "row", style: "align-items:flex-start" }, avatar(u, 32), h("div", { style: "flex:1" },
        h("b", {}, u?.name), c.user_id === p.user_id && h("span", { class: "badge" }, "Autor"), h("span", { class: "mut" }, " " + ago(c.created_at)),
        c.body && h("div", {}, c.body), c.image && h("img", { src: c.image, style: "max-width:60%;border-radius:10px;margin-top:4px" })),
        (isOwner || c.user_id === S.user.id) && h("button", { class: "back", style: "font-size:16px", onclick: async () => { await supabase.from("ob_comments").delete().eq("id", c.id); load(); } }, "🗑"));
    })));
  };
  let img = null; const txt = h("input", { placeholder: "Comentar..." });
  const send = async () => {
    if (!txt.value.trim() && !img) return;
    let image = null; if (img) image = await upload(img, S.user.id); img = null;
    await supabase.from("ob_comments").insert({ post_id: id, user_id: S.user.id, body: txt.value.trim() || null, image }); txt.value = ""; load();
  };
  view.append(h("button", { class: "back", onclick: () => history.back() }, "←"), await postCard(p, new Set((lk || []).map((x) => x.post_id))), list,
    h("div", { class: "bar" }, h("button", { class: "btn ghost sm", onclick: () => pick("image/*", (f) => { img = f; toast("Foto anexada"); }) }, "📷"), txt, h("button", { class: "btn sm", onclick: send }, "Enviar")));
  load();
}
