import { supabase } from "./supabase.js";
import { S, getProfile } from "./state.js";
import { h, go, ago, avatar, media, pick, upload } from "./ui.js";
export async function chatsScreen(view) {
  const { data } = await supabase.from("ob_messages").select("*").or(`from_id.eq.${S.user.id},to_id.eq.${S.user.id}`).order("created_at", { ascending: false }).limit(300);
  const seen = new Map(); (data || []).forEach((m) => { const o = m.from_id === S.user.id ? m.to_id : m.from_id; if (!seen.has(o)) seen.set(o, m); });
  const rows = await Promise.all([...seen].map(async ([o, m]) => { const u = await getProfile(o); return h("div", { class: "row", onclick: () => go("/dm/" + o) }, avatar(u, 46), h("div", { style: "flex:1" }, h("b", {}, u?.name), h("div", { class: "mut" }, m.body || ({ post: "Publicação", image: "Foto", video: "Vídeo", audio: "Áudio" })[m.kind])), h("span", { class: "mut" }, ago(m.created_at))); }));
  view.append(h("h2", {}, "Conversas"), ...(rows.length ? rows : [h("p", { class: "mut center" }, "Pesquise alguém e mande a primeira mensagem.")]));
}
export async function roomScreen(view, _k, peer) {
  const u = await getProfile(peer), box = h("div", { class: "msgs" }), me = S.user.id; view.style.padding = "0";
  const bgKey = "ob_bg_" + peer; const setBg = (url) => { box.style.backgroundImage = url ? `url(${url})` : ""; }; setBg(localStorage.getItem(bgKey));
  const draw = async (m) => {
    let body = [m.body];
    if (m.kind === "post") { const { data: p } = await supabase.from("ob_posts").select("*").eq("id", m.post_id).maybeSingle(); body = p ? [h("div", { onclick: () => go("/post/" + p.id) }, media(p.kind, p.url), h("small", {}, "Ver publicação"))] : ["Publicação removida"]; }
    else if (m.url) body = [media(m.kind, m.url), m.body];
    box.append(h("div", { class: "m" + (m.from_id === me ? " me" : "") }, body)); box.scrollTop = box.scrollHeight;
  };
  const { data } = await supabase.from("ob_messages").select("*").or(`and(from_id.eq.${me},to_id.eq.${peer}),and(from_id.eq.${peer},to_id.eq.${me})`).order("created_at").limit(200);
  for (const m of data || []) await draw(m);
  const ch = supabase.channel("dm-" + me + "-" + peer).on("postgres_changes", { event: "INSERT", schema: "public", table: "ob_messages", filter: "to_id=eq." + me }, (e) => e.new.from_id === peer && draw(e.new)).subscribe();
  const send = async (row) => { const { data: m } = await supabase.from("ob_messages").insert({ from_id: me, to_id: peer, ...row }).select().single(); m && draw(m); };
  const txt = h("input", { placeholder: "Mensagem...", onkeydown: (e) => e.key === "Enter" && go_() }); const go_ = () => { if (txt.value.trim()) { send({ kind: "text", body: txt.value.trim() }); txt.value = ""; } };
  let rec = null, chunks = []; const mic = h("button", { class: "btn ghost sm" }, "🎤");
  mic.onclick = async () => {
    if (rec) { rec.stop(); return; }
    try { const st = await navigator.mediaDevices.getUserMedia({ audio: true }); rec = new MediaRecorder(st); chunks = []; rec.ondataavailable = (e) => chunks.push(e.data);
      rec.onstop = async () => { st.getTracks().forEach((t) => t.stop()); const f = new File(chunks, "audio.webm", { type: "audio/webm" }); rec = null; mic.textContent = "🎤"; send({ kind: "audio", url: await upload(f, me) }); };
      rec.start(); mic.textContent = "⏹"; } catch { alert("Permita o microfone."); }
  };
  view.append(h("div", { class: "bar" }, h("button", { class: "back", onclick: () => history.back() }, "←"), avatar(u, 36), h("b", { style: "flex:1" }, u?.name),
    h("button", { class: "btn ghost sm", onclick: () => pick("image/*", async (f) => { const url = await upload(f, me); localStorage.setItem(bgKey, url); setBg(url); }) }, "🖼")),
    box, h("div", { class: "bar" }, h("button", { class: "btn ghost sm", onclick: () => pick("image/*,video/*", async (f) => send({ kind: f.type.startsWith("video") ? "video" : "image", url: await upload(f, me) })) }, "📎"), txt, mic, h("button", { class: "btn sm", onclick: go_ }, "➤")));
  return () => { supabase.removeChannel(ch); view.style.padding = ""; };
}
