import { supabase } from "./supabase.js";
import { BUCKET, MAX_VIDEO_MB } from "./config.js";
export function h(tag, props = {}, ...kids) {
  const el = document.createElement(tag);
  for (const [k, v] of Object.entries(props || {})) {
    if (k.startsWith("on")) el.addEventListener(k.slice(2), v);
    else if (v === true) el.setAttribute(k, ""); else if (v !== false && v != null) el.setAttribute(k, v);
  }
  el.append(...kids.flat().filter((x) => x != null && x !== false));
  return el;
}
export const go = (p) => { location.hash = "#" + p; };
export const ago = (d) => { const s = (Date.now() - new Date(d)) / 1000; return s < 60 ? "agora" : s < 3600 ? Math.floor(s / 60) + " min" : s < 86400 ? Math.floor(s / 3600) + " h" : Math.floor(s / 86400) + " d"; };
export function toast(msg, onclick) { const t = h("div", { class: "toast", onclick: () => { t.remove(); onclick?.(); } }, msg); document.body.append(t); setTimeout(() => t.remove(), 4000); }
export async function upload(file, folder) {
  if (file.type.startsWith("video") && file.size > MAX_VIDEO_MB * 1048576) throw new Error("Vídeo maior que " + MAX_VIDEO_MB + " MB");
  const ext = (file.name?.split(".").pop() || "bin").toLowerCase().replace(/[^a-z0-9]/g, "");
  const path = `${folder}/${crypto.randomUUID()}.${ext}`;
  const { error } = await supabase.storage.from(BUCKET).upload(path, file, { contentType: file.type });
  if (error) throw error;
  return supabase.storage.from(BUCKET).getPublicUrl(path).data.publicUrl;
}
export const avatar = (p, s = 40) => p?.avatar ? h("img", { class: "av", src: p.avatar, style: `width:${s}px;height:${s}px` }) : h("div", { class: "av ph", style: `width:${s}px;height:${s}px;font-size:${s / 2}px` }, (p?.name || "?")[0].toUpperCase());
export const pick = (accept, cb) => { const i = h("input", { type: "file", accept, onchange: () => i.files[0] && cb(i.files[0]) }); i.click(); };
export const media = (kind, url) => kind === "video" ? h("video", { src: url, controls: true, playsinline: true, preload: "metadata" }) : kind === "audio" ? h("audio", { src: url, controls: true }) : h("img", { src: url, loading: "lazy" });
export function injectCss() {
  document.head.append(h("style", {}, `
:root{--p:#5b4bff;--p2:#c44bff;--bg:#0f0f1a;--card:#1a1a2b;--tx:#f2f2fa;--mut:#8b8ba7}
*{box-sizing:border-box;margin:0}body{background:var(--bg);color:var(--tx);font:15px system-ui,sans-serif;overscroll-behavior:none}
#app{height:100dvh;display:flex;flex-direction:column;max-width:560px;margin:auto}#view{flex:1;overflow:auto;padding:12px;padding-top:max(12px,env(safe-area-inset-top))}
.tabs{display:flex;background:var(--card);padding-bottom:env(safe-area-inset-bottom)}.notabs .tabs{display:none}
.tab{flex:1;background:none;border:0;color:var(--mut);padding:8px;display:flex;flex-direction:column;align-items:center;font-size:11px;gap:2px}.tab.on{color:var(--p2)}
.btn{background:linear-gradient(135deg,var(--p),var(--p2));color:#fff;border:0;border-radius:12px;padding:10px 16px;font-weight:600}.btn.sm{padding:6px 12px;font-size:13px}.btn.ghost{background:#2a2a40}
input,textarea{width:100%;background:#22223a;border:1px solid #33335a;border-radius:12px;color:var(--tx);padding:10px;margin:4px 0;font:inherit}
.card{background:var(--card);border-radius:16px;margin-bottom:14px;overflow:hidden}.card>.hd,.card>.ft,.card>p{padding:10px 12px}.card img,.card video{width:100%;max-height:70vh;object-fit:cover;display:block}
.hd{display:flex;align-items:center;gap:10px}.av{border-radius:50%;object-fit:cover;background:#2a2a40}.av.ph{display:flex;align-items:center;justify-content:center;background:linear-gradient(135deg,var(--p),var(--p2))}
.ft{display:flex;gap:16px;color:var(--mut)}.ft button{background:none;border:0;color:inherit;font-size:14px}.ft .on{color:#ff4b7d}
.row{display:flex;align-items:center;gap:10px;padding:10px 0;border-bottom:1px solid #22223a}.mut{color:var(--mut);font-size:13px}.badge{background:var(--p);border-radius:6px;padding:1px 6px;font-size:11px;margin-left:6px}
.msgs{display:flex;flex-direction:column;gap:6px;flex:1;overflow:auto;padding:8px;background-size:cover;background-position:center}.m{max-width:78%;padding:8px 12px;border-radius:16px;background:#2a2a40;align-self:flex-start;word-break:break-word}.m.me{background:var(--p);align-self:flex-end}.m img,.m video{max-width:100%;border-radius:10px}
.bar{display:flex;gap:6px;align-items:center;padding:8px;background:var(--card)}.bar input{margin:0}.grid{display:grid;grid-template-columns:repeat(3,1fr);gap:3px}.grid img,.grid video{width:100%;aspect-ratio:1;object-fit:cover}
.center{text-align:center;padding:20px 0}.toast{position:fixed;top:max(12px,env(safe-area-inset-top));left:12px;right:12px;max-width:536px;margin:auto;background:var(--p);padding:12px;border-radius:12px;z-index:9;animation:in .3s}
.splash{position:fixed;inset:0;background:radial-gradient(circle,#2b1f6b,#0f0f1a);display:flex;flex-direction:column;align-items:center;justify-content:center;gap:12px;z-index:99;transition:opacity .5s}.splash.out{opacity:0}
.sp-logo{width:110px;height:110px;border-radius:28px;animation:pop 1s ease both}.sp-name{font-size:34px;font-weight:800;animation:in .8s .4s both}.sp-tag{color:var(--mut);animation:in .8s .7s both}
@keyframes pop{from{transform:scale(.3) rotate(-90deg);opacity:0}to{transform:none;opacity:1}}@keyframes in{from{transform:translateY(14px);opacity:0}to{transform:none;opacity:1}}
.back{background:none;border:0;color:var(--tx);font-size:22px}`));
}
