import { supabase } from "./supabase.js";
import { S, getProfile, dropCache } from "./state.js";
import { h, go, avatar, media, pick, upload, toast } from "./ui.js";
export async function profileScreen(view, id) {
  const u = await getProfile(id); if (!u) return view.append(h("p", { class: "center" }, "Perfil não encontrado."));
  const own = id === S.user.id;
  const cnt = async (col, v) => (await supabase.from("ob_follows").select("*", { count: "exact", head: true }).eq(col, v)).count || 0;
  const [seg, ing] = [await cnt("following", id), await cnt("follower", id)];
  const rel = async () => ({ i: !!(await supabase.from("ob_follows").select("follower").match({ follower: S.user.id, following: id }).maybeSingle()).data, he: !!(await supabase.from("ob_follows").select("follower").match({ follower: id, following: S.user.id }).maybeSingle()).data });
  const r = own ? null : await rel();
  const fb = h("button", { class: "btn sm" }), paint = () => { fb.textContent = r.i ? "Seguindo" : r.he ? "Seguir de volta" : "Seguir"; fb.className = "btn sm" + (r.i ? " ghost" : ""); };
  if (!own) { paint(); fb.onclick = async () => { if (r.i) await supabase.from("ob_follows").delete().match({ follower: S.user.id, following: id }); else await supabase.from("ob_follows").insert({ follower: S.user.id, following: id }); r.i = !r.i; paint(); }; }
  const { data: posts } = await supabase.from("ob_posts").select("*").eq("user_id", id).order("created_at", { ascending: false });
  const name = h("input", { value: u.name }), bio = h("input", { value: u.bio || "", placeholder: "Bio" });
  view.append(h("div", { class: "center" }, avatar(u, 90), h("h2", {}, u.name), h("div", { class: "mut" }, "@" + u.username), u.bio && h("p", {}, u.bio), h("p", { class: "mut" }, `${seg} seguidores · ${ing} seguindo · ${posts?.length || 0} posts`),
    own ? [h("button", { class: "btn ghost sm", onclick: () => pick("image/*", async (f) => { u.avatar = await upload(f, S.user.id); await supabase.from("ob_profiles").update({ avatar: u.avatar }).eq("id", id); dropCache(id); S.me = u; go("/me"); location.reload(); }) }, "Trocar foto"),
      name, bio, h("button", { class: "btn sm", onclick: async () => { await supabase.from("ob_profiles").update({ name: name.value.trim() || u.name, bio: bio.value.trim() }).eq("id", id); dropCache(id); toast("Perfil salvo"); } }, "Salvar"),
      h("p", {}, h("button", { class: "btn ghost sm", onclick: () => supabase.auth.signOut() }, "Sair"))]
      : h("div", {}, fb, " ", h("button", { class: "btn ghost sm", onclick: () => go("/dm/" + id) }, "Mensagem"))),
    h("div", { class: "grid" }, (posts || []).map((p) => h("div", { onclick: () => go("/post/" + p.id) }, media(p.kind, p.url)))));
}
