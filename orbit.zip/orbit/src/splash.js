import { h } from "./ui.js";
export function splash(ms = 2000) {
  const el = h("div", { class: "splash" }, h("img", { class: "sp-logo", src: "/src/assets/icon.png" }), h("div", { class: "sp-name" }, "Orbit"), h("div", { class: "sp-tag" }, "Conecte-se com o seu mundo"));
  document.body.append(el);
  return new Promise((r) => setTimeout(() => { el.classList.add("out"); setTimeout(() => { el.remove(); r(); }, 500); }, ms));
}
