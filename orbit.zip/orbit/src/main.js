import { initSupabase, supabase } from "./supabase.js";
import { S, loadMe } from "./state.js";
import { h, injectCss, go, toast } from "./ui.js";
import { splash } from "./splash.js";
import { authScreen } from "./auth.js";
import { feedScreen, newPostScreen, postScreen } from "./feed.js";
import { searchScreen } from "./search.js";
import { chatsScreen, roomScreen } from "./chat.js";
import { profileScreen } from "./profile.js";
import { getProfile } from "./state.js";

const routes = { feed: feedScreen, search: searchScreen, chats: chatsScreen, new: newPostScreen, me: (v) => profileScreen(v, S.user.id), user: profileScreen, post: postScreen, dm: (v, a) => roomScreen(v, "dm", a) };
const TABS = [["feed", "Início", "🏠"], ["search", "Buscar", "🔍"], ["new", "Postar", "➕"], ["chats", "Chat", "💬"], ["me", "Perfil", "👤"]];
let view, appEl, cleanup = null, token = 0, started = false;

async function render() {
  if (!started) return; cleanup?.(); cleanup = null; const my = ++token;
  const [seg, arg] = (location.hash.replace(/^#\/?/, "") || "feed").split("/"); const name = routes[seg] ? seg : "feed";
  appEl.classList.toggle("notabs", ["dm", "post"].includes(name));
  appEl.querySelectorAll(".tab").forEach((t) => t.classList.toggle("on", t.dataset.r === name));
  view.replaceChildren(); view.scrollTop = 0;
  try { const c = await routes[name](view, arg); if (my !== token) c?.(); else cleanup = c || null; }
  catch (e) { console.error(e); view.replaceChildren(h("p", { class: "center" }, "Algo deu errado. ", h("button", { class: "btn sm", onclick: render }, "Tentar de novo"))); }
}

function notifications() {
  if ("Notification" in window && Notification.permission === "default") Notification.requestPermission();
  const text = { like: "curtiu sua publicação", comment: "comentou na sua publicação", follow: "começou a seguir você", message: "enviou uma mensagem" };
  supabase.channel("notifs").on("postgres_changes", { event: "INSERT", schema: "public", table: "ob_notifs", filter: "user_id=eq." + S.user.id }, async (e) => {
    const a = await getProfile(e.new.actor_id), msg = `${a?.name} ${text[e.new.type] || ""}`;
    const dest = e.new.type === "message" ? "/dm/" + e.new.actor_id : e.new.post_id ? "/post/" + e.new.post_id : "/user/" + e.new.actor_id;
    toast("🔔 " + msg, () => go(dest)); try { if (Notification.permission === "granted" && document.hidden) new Notification("Orbit", { body: msg, icon: "/src/assets/icon.png" }); } catch {}
  }).subscribe();
}

function startApp() {
  document.body.replaceChildren(); view = h("main", { id: "view" });
  appEl = h("div", { id: "app" }, view, h("nav", { class: "tabs" }, TABS.map(([r, l, i]) => h("button", { class: "tab", "data-r": r, onclick: () => go("/" + r) }, h("span", { style: "font-size:20px" }, i), l))));
  document.body.append(appEl); started = true; window.addEventListener("hashchange", render);
  notifications(); if (!location.hash) location.hash = "#/feed"; else render();
}

async function boot(notice = "") {
  injectCss(); document.body.replaceChildren(); const sp = splash(); await initSupabase();
  const session = supabase ? (await supabase.auth.getSession()).data?.session : null; await sp;
  const show = (el) => document.body.replaceChildren(h("div", { id: "app" }, h("main", { id: "view" }, el)));
  if (!supabase) return show(h("p", { class: "center" }, "Sem conexão. ", h("button", { class: "btn sm", onclick: () => boot() }, "Tentar de novo")));
  supabase.auth.onAuthStateChange((ev) => { if (ev === "SIGNED_OUT") location.reload(); });
  if (!session) return show(authScreen(() => boot(), notice));
  S.user = session.user; S.me = await loadMe(session.user);
  if (!S.me) return show(authScreen(() => boot(), "Rode o SQL do Supabase (veja o README)."));
  startApp();
}
boot();
