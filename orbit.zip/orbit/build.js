// Gera a pasta "dist" (a página que o navegador abre) a partir do JavaScript em src/.
// Não precisa de npm install: só Node.js.
import { cpSync, existsSync, mkdirSync, readFileSync, rmSync, writeFileSync } from "node:fs";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";

const root = dirname(fileURLToPath(import.meta.url));
const dist = join(root, "dist");

rmSync(dist, { recursive: true, force: true });
mkdirSync(dist, { recursive: true });
cpSync(join(root, "src"), join(dist, "src"), { recursive: true });

const page = [
  "<!doctype html>",
  '<html lang="pt-BR">',
  "<head>",
  '<meta charset="UTF-8" />',
  '<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover" />',
  '<meta name="theme-color" content="#5b4bff" />',
  '<link rel="icon" href="/src/assets/icon.png" />',
  "<title>Orbit</title>",
  "</head>",
  "<body>",
  '<script type="module" src="/src/main.js"></script>',
  "</body>",
  "</html>",
  "",
].join("\n");
writeFileSync(join(dist, "index.html"), page);

if (process.env.NETLIFY && existsSync(join(root, "orbit.apk"))) cpSync(join(root, "orbit.apk"), join(dist, "orbit.apk"));
const { version } = JSON.parse(readFileSync(join(root, "package.json"), "utf8"));
writeFileSync(join(dist, "version.json"), JSON.stringify({ version }));
console.log("Orbit pronto na pasta dist/");
