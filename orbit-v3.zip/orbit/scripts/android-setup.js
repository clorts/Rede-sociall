// Roda depois de "npx cap add android": permissões, ícone do app e chave fixa de assinatura
// (para o APK novo instalar por cima do antigo).
import { copyFileSync, existsSync, mkdirSync, readFileSync, readdirSync, writeFileSync } from "node:fs";
import { homedir } from "node:os";
import { join } from "node:path";

const manifestPath = join("android", "app", "src", "main", "AndroidManifest.xml");
if (!existsSync(manifestPath)) throw new Error("Rode 'npx cap add android' antes deste script.");

const permissions = [
  "android.permission.INTERNET",
  "android.permission.ACCESS_NETWORK_STATE",
  "android.permission.CAMERA",
  "android.permission.RECORD_AUDIO",
  "android.permission.READ_MEDIA_IMAGES",
  "android.permission.READ_MEDIA_VIDEO",
  "android.permission.MODIFY_AUDIO_SETTINGS", // necessário para gravar áudio e ligar dentro do app
  "android.permission.POST_NOTIFICATIONS",
  "android.permission.VIBRATE",
  "android.permission.WAKE_LOCK",
];
const features = ['<uses-feature android:name="android.hardware.camera" android:required="false" />', '<uses-feature android:name="android.hardware.microphone" android:required="false" />'];
let manifest = readFileSync(manifestPath, "utf8");
const missing = permissions.filter((p) => !manifest.includes(`"${p}"`));
const lines = [...missing.map((p) => `    <uses-permission android:name="${p}" />`), ...features.filter((f) => !manifest.includes(f.slice(0, 50))).map((f) => "    " + f)];
if (lines.length > 0) manifest = manifest.replace("<application", `${lines.join("\n")}\n\n    <application`);
// Ícone e cor da notificação (sem isso o Android mostra um quadrado branco)
if (!manifest.includes("default_notification_icon")) manifest = manifest.replace(/<application([^>]*)>/, `<application$1>\n        <meta-data android:name="com.google.firebase.messaging.default_notification_icon" android:resource="@drawable/ic_stat_orbit" />\n        <meta-data android:name="com.google.firebase.messaging.default_notification_color" android:resource="@color/orbit_notif" />`);
writeFileSync(manifestPath, manifest);

// Ícone do app
const resDir = join("android", "app", "src", "main", "res");
if (existsSync(join("native", "res"))) {
  for (const d of readdirSync(join("native", "res"))) {
    mkdirSync(join(resDir, d), { recursive: true });
    for (const f of readdirSync(join("native", "res", d))) copyFileSync(join("native", "res", d, f), join(resDir, d, f));
  }
  const valuesDir = join(resDir, "values");
  mkdirSync(valuesDir, { recursive: true });
  writeFileSync(join(valuesDir, "orbit_colors.xml"), '<?xml version="1.0" encoding="utf-8"?>\n<resources>\n    <color name="orbit_notif">#6C5CFF</color>\n</resources>\n');
  writeFileSync(join(valuesDir, "ic_launcher_background.xml"), '<?xml version="1.0" encoding="utf-8"?>\n<resources>\n    <color name="ic_launcher_background">#5B4BFF</color>\n</resources>\n');
}

// Chave de assinatura fixa
const keystore = join("native", "debug.keystore");
if (existsSync(keystore)) {
  const dir = join(homedir(), ".android");
  mkdirSync(dir, { recursive: true });
  copyFileSync(keystore, join(dir, "debug.keystore"));
}
// Firebase (push com o app fechado): coloque o arquivo em native/google-services.json
const gs = join("native", "google-services.json");
if (existsSync(gs)) { copyFileSync(gs, join("android", "app", "google-services.json")); console.log("Firebase ativado (google-services.json)"); }
else console.log("AVISO: native/google-services.json não encontrado - o app funciona, mas sem notificações push.");
console.log("Android configurado");
