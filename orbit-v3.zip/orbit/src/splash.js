import { h } from "./ui.js";
export const logoMark = () => h("div", { class: "mark" }, h("div", { class: "orb b" }), h("div", { class: "orb" }), h("img", { src: "/src/assets/icon.png", alt: "Orbit" }));
export function splash(ms = 1500) {
  const el = h("div", { class: "splash" }, logoMark(), h("div", { class: "sp-name" }, "Orbit"), h("div", { class: "sp-tag" }, "Conecte-se com o seu mundo"));
  document.body.append(el);
  return new Promise((r) => setTimeout(() => { el.classList.add("out"); setTimeout(() => { el.remove(); r(); }, 500); }, ms));
}
