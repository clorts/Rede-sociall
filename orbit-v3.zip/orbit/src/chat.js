import { supabase } from "./supabase.js";
import { S, getProfile } from "./state.js";
import { h, go, ago, avatar, media, pick, upload, toast, icon, empty, swr, forget, put, fmt } from "./ui.js";
import { startCall } from "./calls.js";

const LABEL = { post: "Publicação", image: "Foto", video: "Vídeo", audio: "Áudio" };
const preview = (m) => (m.from_id === S.user.id ? "Você: " : "") + (m.kind === "call" ? m.body : m.body || LABEL[m.kind] || "");
const title = () => h("h2", { class: "title" }, "Conversas");

export function chatsScreen(page) {
  page.append(title(), ...[1, 2, 3].map(() => h("div", { class: "skel", style: "height:62px;border-radius:18px;margin-bottom:10px" })));
  return swr("chats", async () => {
    const { data, error } = await supabase.from("ob_messages").select("*").or(`from_id.eq.${S.user.id},to_id.eq.${S.user.id}`).order("created_at", { ascending: false }).limit(300);
    if (error) throw error;
    const seen = new Map(), unread = new Map();
    (data || []).forEach((m) => {
      const o = m.from_id === S.user.id ? m.to_id : m.from_id; if (!seen.has(o)) seen.set(o, m);
      if (m.to_id === S.user.id && m.read_at === null) unread.set(o, (unread.get(o) || 0) + 1);
    });
    return Promise.all([...seen].map(async ([o, m]) => ({ o, m, u: await getProfile(o), n: unread.get(o) || 0 })));
  }, (rows) => put(page, title(), rows.length ? rows.map(({ o, m, u, n }) => h("div", { class: "row" + (n ? " new" : ""), onclick: () => go("/dm/" + o) }, avatar(u, 50, true),
    h("div", { class: "grow" }, h("b", {}, u?.name || "Usuário"), h("div", { class: "mut pv", style: "white-space:nowrap;overflow:hidden;text-overflow:ellipsis" }, preview(m))),
    h("div", { class: "rt2" }, h("span", { class: "mut" }, ago(m.created_at)), n ? h("span", { class: "unread" }, n > 99 ? "99+" : String(n)) : null)))
    : empty("chat", "Nenhuma conversa ainda", "Busque alguém e mande a primeira mensagem.", h("button", { class: "btn", onclick: () => go("/search") }, "Buscar pessoas"))));
}

export async function roomScreen(page, _k, peer) {
  const me = S.user.id, u = await getProfile(peer);
  if (!u) return page.append(empty("user", "Conversa não encontrada", "Essa pessoa não existe mais."));
  const box = h("div", { class: "msgs" }), shown = new Set(); let near = true;
  box.onscroll = () => (near = box.scrollHeight - box.scrollTop - box.clientHeight < 160);
  box.addEventListener("load", () => near && (box.scrollTop = box.scrollHeight), true);
  const bgKey = "ob_bg_" + peer, setBg = (url) => { box.style.backgroundImage = url ? `url(${url})` : ""; }; setBg(localStorage.getItem(bgKey));
  const down = () => { box.scrollTop = box.scrollHeight; };

  const bubble = async (m) => {
    let body = [m.body];
    if (m.kind === "post") { const { data: p } = await supabase.from("ob_posts").select("*").eq("id", m.post_id).maybeSingle(); body = p ? [h("div", { onclick: () => go("/post/" + p.id) }, media(p.kind, p.url), h("small", {}, "Ver publicação"))] : ["Publicação removida"]; }
    else if (m.kind === "call") body = [h("div", { class: "callmsg", onclick: () => startCall(peer, /vídeo/.test(m.body)) }, icon(/vídeo/.test(m.body) ? "video" : "phone", 18), h("span", {}, m.body))];
    else if (m.url) body = [media(m.kind, m.url), m.body];
    return h("div", { class: "m" + (m.from_id === me ? " me" : "") }, body, h("span", { class: "t" }, new Date(m.created_at).toLocaleTimeString("pt-BR", { hour: "2-digit", minute: "2-digit" })));
  };
  const add = async (m) => { if (shown.has(m.id)) return; shown.add(m.id); const b = await bubble(m); box.append(b); near = true; down(); };
  const markRead = async () => { const { error } = await supabase.from("ob_messages").update({ read_at: new Date().toISOString() }).eq("to_id", me).eq("from_id", peer).is("read_at", null); if (!error) window.dispatchEvent(new Event("ob:unread")); };

  const send = async (row) => {
    const { data: m, error } = await supabase.from("ob_messages").insert({ from_id: me, to_id: peer, ...row }).select().single();
    if (error) { toast("Não foi possível enviar. Tente de novo.", null, "x"); return false; }
    forget("chats"); await add(m); return true;
  };
  const sendFile = async (f, kind) => {
    const ph = h("div", { class: "m me pend" }, kind === "audio" ? "Enviando áudio…" : "Enviando…"); box.append(ph); down();
    try { const url = await upload(f, me); await send({ kind, url }); } catch (e) { toast(e.message || "Falha no envio", null, "x"); }
    ph.remove();
  };

  /* ----- gravação de áudio ----- */
  let rec = null, chunks = [], stream = null, cancelled = false, t0 = 0, tick = null;
  const composer = h("div", { class: "composer empty" }), timer = h("span", { class: "rt" }, "0:00"), mic = h("button", { class: "ib micbtn", "aria-label": "Gravar áudio", onclick: () => (rec ? stopRec(false) : startRec()) }, icon("mic", 20));
  const recbar = h("div", { class: "recbar" }, h("i", { class: "dot" }), timer, h("span", { class: "mut grow" }, "Gravando…"), h("button", { class: "ib plain danger", "aria-label": "Cancelar gravação", onclick: () => stopRec(true) }, icon("trash", 20)));
  const recUI = (on) => { composer.classList.toggle("recording", on); mic.classList.toggle("send", on); mic.replaceChildren(icon(on ? "send" : "mic", on ? 19 : 20)); };
  async function startRec() {
    const fallback = () => pick("audio/*", (f) => sendFile(f, "audio"), "microphone");
    if (!navigator.mediaDevices?.getUserMedia || typeof MediaRecorder === "undefined") { toast("Gravação não suportada aqui. Escolha um áudio.", null, "mic"); return fallback(); }
    try { stream = await navigator.mediaDevices.getUserMedia({ audio: { echoCancellation: true, noiseSuppression: true } }); }
    catch (e) { return toast(e.name === "NotAllowedError" ? "Permita o microfone nas permissões do app." : "Não foi possível acessar o microfone.", null, "mic"); }
    const mime = ["audio/webm;codecs=opus", "audio/mp4", "audio/webm", "audio/ogg;codecs=opus"].find((t) => MediaRecorder.isTypeSupported?.(t)) || "";
    try { rec = mime ? new MediaRecorder(stream, { mimeType: mime }) : new MediaRecorder(stream); }
    catch { stream.getTracks().forEach((t) => t.stop()); rec = null; toast("Gravação não suportada aqui. Escolha um áudio.", null, "mic"); return fallback(); }
    chunks = []; cancelled = false; const r = rec;
    r.ondataavailable = (e) => e.data?.size && chunks.push(e.data);
    r.onstop = () => {
      stream?.getTracks().forEach((t) => t.stop()); clearInterval(tick); recUI(false); rec = null;
      const secs = (Date.now() - t0) / 1000, type = (r.mimeType || mime || "audio/webm").split(";")[0];
      if (cancelled) return; if (secs < 1 || !chunks.length) return toast("Segure um pouco mais para gravar", null, "mic");
      const ext = type.includes("mp4") ? "m4a" : type.includes("ogg") ? "ogg" : "webm";
      sendFile(new File(chunks, `audio.${ext}`, { type }), "audio");
    };
    r.start(500); t0 = Date.now(); timer.textContent = "0:00"; tick = setInterval(() => (timer.textContent = fmt((Date.now() - t0) / 1000)), 500); recUI(true);
  }
  function stopRec(cancel) { if (!rec) return; cancelled = cancel; try { rec.stop(); } catch {} }

  const txt = h("input", { placeholder: "Mensagem...", enterkeyhint: "send", oninput: () => composer.classList.toggle("empty", !txt.value.trim()), onkeydown: (e) => e.key === "Enter" && submit() });
  const submit = () => { const t = txt.value.trim(); if (!t) return; txt.value = ""; composer.classList.add("empty"); send({ kind: "text", body: t }).then((ok) => { if (!ok) { txt.value = t; composer.classList.remove("empty"); } }); txt.focus(); };
  composer.append(h("button", { class: "ib clipbtn", "aria-label": "Anexar", onclick: () => pick("image/*,video/*", (f) => sendFile(f, f.type.startsWith("video") ? "video" : "image")) }, icon("clip", 20)), txt, recbar, mic, h("button", { class: "ib send sendtxt", "aria-label": "Enviar", onclick: submit }, icon("send", 19)));

  page.append(h("div", { class: "chathd" }, h("button", { class: "ib plain", "aria-label": "Voltar", onclick: () => history.back() }, icon("back", 22)),
    h("div", { style: "display:flex;gap:10px;align-items:center;flex:1;min-width:0", onclick: () => go("/user/" + peer) }, avatar(u, 38, true), h("b", {}, u.name)),
    h("button", { class: "ib plain", "aria-label": "Ligação de voz", onclick: () => startCall(peer, false) }, icon("phone", 20)),
    h("button", { class: "ib plain", "aria-label": "Chamada de vídeo", onclick: () => startCall(peer, true) }, icon("video", 21)),
    h("button", { class: "ib plain", "aria-label": "Fundo da conversa", onclick: () => pick("image/*", async (f) => { try { const url = await upload(f, me, 1200); localStorage.setItem(bgKey, url); setBg(url); } catch { toast("Não foi possível trocar o fundo", null, "x"); } }) }, icon("image", 20))),
    box, composer);

  const { data } = await supabase.from("ob_messages").select("*").or(`and(from_id.eq.${me},to_id.eq.${peer}),and(from_id.eq.${peer},to_id.eq.${me})`).order("created_at", { ascending: false }).limit(200);
  const hist = (data || []).reverse(); hist.forEach((m) => shown.add(m.id));
  box.append(...await Promise.all(hist.map(bubble))); down(); markRead();

  const ch = supabase.channel("dm-" + me + "-" + peer + "-" + Date.now()).on("postgres_changes", { event: "INSERT", schema: "public", table: "ob_messages", filter: "to_id=eq." + me }, (e) => { if (e.new.from_id === peer) { add(e.new); markRead(); } }).subscribe();
  const onCall = (e) => e.detail.to_id === peer && add(e.detail); window.addEventListener("ob:callmsg", onCall);
  return () => { supabase.removeChannel(ch); window.removeEventListener("ob:callmsg", onCall); stopRec(true); clearInterval(tick); };
}
