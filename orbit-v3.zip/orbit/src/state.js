import { supabase } from "./supabase.js";
export const S = { user: null, me: null };
const cache = new Map();
export const cleanUser = (s) => String(s || "").toLowerCase().replace(/^@/, "").replace(/[^a-z0-9_.]/g, "").slice(0, 20);
export async function getProfile(id) {
  if (!id) return null;
  if (cache.has(id)) return cache.get(id);
  const { data } = await supabase.from("ob_profiles").select("*").eq("id", id).maybeSingle();
  if (data) cache.set(id, data); return data;
}
export const dropCache = (id) => cache.delete(id);
export async function loadMe(user) {
  let { data } = await supabase.from("ob_profiles").select("*").eq("id", user.id).maybeSingle();
  if (data) return data;
  const m = user.user_metadata || {}, base = cleanUser(m.username || (user.email || "").split("@")[0]) || "user";
  // se o @usuário já existir, tenta de novo com números no final
  for (let i = 0; i < 5 && !data; i++) {
    const username = i ? base.slice(0, 15) + Math.floor(Math.random() * 9999) : base;
    const r = await supabase.from("ob_profiles").insert({ id: user.id, username, name: m.name || base }).select().single();
    data = r.data;
    if (!data && r.error && !/duplicate|unique/i.test(r.error.message)) break;
  }
  return data;
}
