import { supabase } from "./supabase.js";
import { h, go, avatar, icon, empty } from "./ui.js";
export function searchScreen(page) {
  const out = h("div", {}, empty("users", "Encontre pessoas", "Busque pelo nome ou @usuário.")); let t;
  const input = h("input", { placeholder: "Pesquisar pessoas", oninput: () => { clearTimeout(t); t = setTimeout(async () => {
    const q = input.value.trim().replace(/[%,()*]/g, ""); if (q.length < 2) return out.replaceChildren(empty("users", "Encontre pessoas", "Busque pelo nome ou @usuário."));
    const { data } = await supabase.from("ob_profiles").select("*").or(`name.ilike.%${q}%,username.ilike.%${q}%`).limit(30);
    out.replaceChildren(...(data?.length ? data.map((u) => h("div", { class: "row", onclick: () => go("/user/" + u.id) }, avatar(u, 48, true), h("div", { class: "grow" }, h("b", {}, u.name), h("div", { class: "mut" }, "@" + u.username)))) : [empty("search", "Ninguém encontrado", "Tente outro nome.")]));
  }, 250); } });
  page.append(h("h2", { class: "title" }, "Buscar"), h("div", { class: "sbox" }, icon("search", 20), input), out);
}
