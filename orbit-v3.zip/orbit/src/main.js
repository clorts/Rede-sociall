import { initSupabase, supabase } from "./supabase.js";
import { S, loadMe, getProfile } from "./state.js";
import { h, go, toast, icon, empty } from "./ui.js";
import { splash } from "./splash.js";
import { authScreen } from "./auth.js";
import { feedScreen, newPostScreen, postScreen } from "./feed.js";
import { searchScreen } from "./search.js";
import { chatsScreen, roomScreen } from "./chat.js";
import { profileScreen } from "./profile.js";
import { initCalls, checkRinging } from "./calls.js";
import { initPush } from "./push.js";

const routes = { feed: feedScreen, search: searchScreen, chats: chatsScreen, new: newPostScreen, me: (v) => profileScreen(v, S.user.id), user: profileScreen, post: postScreen, dm: (v, a) => roomScreen(v, "dm", a) };
const TABS = [["feed", "Início", "home"], ["search", "Buscar", "search"], ["new", "Postar", "plus"], ["chats", "Conversas", "chat"], ["me", "Perfil", "user"]];
let view, appEl, ind, cleanup = null, token = 0, started = false, first = true, authHooked = false;

async function render() {
  if (!started) return; cleanup?.(); cleanup = null; const my = ++token;
  const [seg, arg] = (location.hash.replace(/^#\/?/, "") || "feed").split("/"); const name = routes[seg] ? seg : "feed";
  appEl.classList.toggle("notabs", ["dm", "post"].includes(name));
  const i = TABS.findIndex((t) => t[0] === name); ind.style.opacity = i < 0 || name === "new" ? 0 : 1; if (i >= 0) ind.style.transform = `translateX(${i * 100}%)`;
  appEl.querySelectorAll(".tab").forEach((t) => t.classList.toggle("on", t.dataset.r === name));
  const page = h("div", { class: "page" }); view.classList.toggle("flush", name === "dm"); view.replaceChildren(page); view.scrollTop = 0;
  try { const c = await routes[name](page, arg); if (my !== token) c?.(); else cleanup = c || null; }
  catch (e) { console.error(e); page.replaceChildren(empty("x", "Algo deu errado", "Verifique sua conexão e tente de novo.", h("button", { class: "btn sm", onclick: render }, "Tentar de novo"))); }
}

// Bolinha de mensagens não lidas na aba Conversas
async function refreshBadge() {
  const b = document.getElementById("bdg"); if (!b || !S.user) return;
  const { count, error } = await supabase.from("ob_messages").select("id", { count: "exact", head: true }).eq("to_id", S.user.id).is("read_at", null);
  const n = error ? 0 : count || 0; b.textContent = n > 99 ? "99+" : String(n); b.classList.toggle("on", n > 0);
}

const TXT = { like: "curtiu sua publicação", comment: "comentou na sua publicação", follow: "começou a seguir você", missed_call: "ligou para você" };
function notifications() {
  if (!window.Capacitor?.isNativePlatform?.() && "Notification" in window && Notification.permission === "default") Notification.requestPermission();
  supabase.channel("notifs-" + S.user.id).on("postgres_changes", { event: "INSERT", schema: "public", table: "ob_notifs", filter: "user_id=eq." + S.user.id }, async (e) => {
    const n = e.new; if (n.type === "call") return; // o toque da chamada é tratado em calls.js
    const a = await getProfile(n.actor_id), isMsg = n.type === "message";
    if (isMsg) { refreshBadge(); if (location.hash === "#/dm/" + n.actor_id) return; }
    const msg = isMsg ? `${a?.name}: ${n.body || "nova mensagem"}` : `${a?.name} ${TXT[n.type] || ""}`;
    const dest = isMsg || n.type === "missed_call" ? "/dm/" + n.actor_id : n.post_id ? "/post/" + n.post_id : "/user/" + n.actor_id;
    toast(msg, () => go(dest), n.type === "missed_call" ? "phone" : "bell");
    try { if (typeof Notification !== "undefined" && Notification.permission === "granted" && document.hidden) new Notification("Orbit", { body: msg, icon: "/src/assets/icon.png" }); } catch {}
  }).subscribe();
  supabase.channel("msgs-" + S.user.id).on("postgres_changes", { event: "INSERT", schema: "public", table: "ob_messages", filter: "to_id=eq." + S.user.id }, () => refreshBadge()).subscribe();
  window.addEventListener("ob:unread", refreshBadge);
  document.addEventListener("visibilitychange", () => { if (!document.hidden) { refreshBadge(); checkRinging(); } });
  refreshBadge();
}

function startApp() {
  document.body.replaceChildren(); view = h("main", { id: "view" }); ind = h("div", { class: "ind" });
  appEl = h("div", { id: "app" }, view, h("nav", { class: "tabs" }, ind, TABS.map(([r, l, i]) => h("button", { class: "tab" + (r === "new" ? " fab" : ""), "data-r": r, "aria-label": l, onclick: () => { if (location.hash === "#/" + r) view.scrollTo({ top: 0, behavior: "smooth" }); else go("/" + r); } }, icon(i, 22), h("span", { class: "l" }, l), r === "chats" && h("span", { class: "bdg", id: "bdg" })))));
  document.body.append(appEl); started = true; window.addEventListener("hashchange", render);
  notifications(); initCalls(); initPush(); if (!location.hash) location.hash = "#/feed"; else render();
}

async function boot(notice = "") {
  document.body.replaceChildren(); const sp = splash(first ? 1300 : 400); first = false; await initSupabase();
  const session = supabase ? (await supabase.auth.getSession()).data?.session : null; await sp;
  const show = (el) => document.body.replaceChildren(h("div", { id: "app" }, h("main", { id: "view" }, el)));
  if (!supabase) return show(empty("x", "Sem conexão", "Não foi possível conectar ao Orbit.", h("button", { class: "btn sm", onclick: () => boot() }, "Tentar de novo")));
  if (!authHooked) { authHooked = true; supabase.auth.onAuthStateChange((ev) => { if (ev === "SIGNED_OUT") location.reload(); }); }
  if (!session) return show(authScreen(() => boot(), notice));
  S.user = session.user; S.me = await loadMe(session.user);
  if (!S.me) return show(authScreen(() => boot(), "Não foi possível carregar seu perfil. Rode o SQL do Supabase (veja o README)."));
  startApp();
}
boot();
