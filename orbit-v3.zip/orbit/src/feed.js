import { supabase } from "./supabase.js";
import { S, getProfile } from "./state.js";
import { h, go, ago, avatar, media, pick, upload, toast, icon, sheet, empty, skeletons, swr, forget, put } from "./ui.js";

const topbar = () => h("header", { class: "top" }, h("img", { src: "/src/assets/icon.png", alt: "" }), h("span", { class: "word" }, "Orbit"));
const backbar = (t) => h("header", { class: "top" }, h("button", { class: "ib", "aria-label": "Voltar", onclick: () => history.back() }, icon("back", 20)), h("span", { class: "word", style: "font-size:20px" }, t));

// Publicações já carregadas: abrir uma publicação nunca depende de um segundo carregamento.
const cache = new Map();
const countBy = (rows) => { const m = new Map(); (rows || []).forEach((x) => m.set(x.post_id, (m.get(x.post_id) || 0) + 1)); return m; };

// Junta autor + contagem de curtidas/comentários sem usar "embed" do PostgREST
// (o embed ficava ambíguo por causa da tabela de curtidas e quebrava a abertura do post).
export async function hydrate(rows) {
  if (!rows?.length) return [];
  const ids = rows.map((p) => p.id);
  const [l, c, authors] = await Promise.all([
    supabase.from("ob_likes").select("post_id").in("post_id", ids),
    supabase.from("ob_comments").select("post_id").in("post_id", ids),
    Promise.all([...new Set(rows.map((p) => p.user_id))].map(getProfile)),
  ]);
  const lc = countBy(l.data), cc = countBy(c.data), by = new Map(authors.filter(Boolean).map((a) => [a.id, a]));
  return rows.map((p) => { const o = { ...p, author: by.get(p.user_id) || null, nLikes: lc.get(p.id) || 0, nComms: cc.get(p.id) || 0 }; cache.set(o.id, o); return o; });
}

export function postCard(p, mine = new Set()) {
  let liked = mine.has(p.id), n = p.nLikes || 0, last = 0;
  const cnt = h("span"), lb = h("button", { class: "act", "aria-label": "Curtir" }, icon("heart", 22), cnt), burst = h("div", { class: "burst" }, icon("heart", 88));
  const paint = () => { lb.classList.toggle("on", liked); cnt.textContent = n || ""; }; paint();
  const toggle = async () => {
    liked = !liked; n += liked ? 1 : -1; paint();
    if (liked) { lb.classList.remove("pop"); void lb.offsetWidth; lb.classList.add("pop"); }
    const r = liked ? await supabase.from("ob_likes").insert({ post_id: p.id, user_id: S.user.id }) : await supabase.from("ob_likes").delete().match({ post_id: p.id, user_id: S.user.id });
    if (r.error) { liked = !liked; n += liked ? 1 : -1; paint(); toast("Não foi possível curtir", null, "x"); }
  };
  lb.onclick = toggle;
  const m = h("div", { class: "media", onclick: (e) => {
    if (e.target.closest("video,audio")) return; const t = Date.now();
    if (t - last < 300) { burst.classList.remove("go"); void burst.offsetWidth; burst.classList.add("go"); if (!liked) toggle(); } last = t;
  } }, media(p.kind, p.url), burst);
  const card = h("article", { class: "post" },
    h("div", { class: "hd" }, h("div", { style: "display:flex;gap:11px;align-items:center;flex:1;min-width:0", onclick: () => go("/user/" + p.user_id) }, avatar(p.author, 42, true), h("div", { class: "grow" }, h("b", {}, p.author?.name || "Usuário"), h("div", { class: "mut" }, "@" + (p.author?.username || "") + " · " + ago(p.created_at)))),
      p.user_id === S.user.id && h("button", { class: "ib plain danger", "aria-label": "Apagar", onclick: () => {
        const close = sheet("Apagar publicação?", h("p", { class: "mut" }, "Essa ação não pode ser desfeita."), h("button", { class: "btn block", onclick: async () => {
          close(); const { error } = await supabase.from("ob_posts").delete().eq("id", p.id);
          if (error) return toast("Não foi possível apagar", null, "x");
          cache.delete(p.id); forget("feed"); card.remove(); toast("Publicação apagada", null, "check"); if (location.hash.startsWith("#/post/")) history.back();
        } }, "Apagar"), h("button", { class: "btn ghost block", onclick: () => close() }, "Cancelar"));
      } }, icon("trash", 20))),
    m, h("div", { class: "acts" }, lb, h("button", { class: "act", "aria-label": "Comentários", onclick: () => go("/post/" + p.id) }, icon("chat", 22), h("span", {}, p.nComms || "")), h("button", { class: "act", "aria-label": "Enviar", onclick: () => sharePost(p) }, icon("send", 21))),
    p.caption && h("p", { class: "cap" }, h("b", {}, (p.author?.name || "") + " "), p.caption));
  return card;
}

async function sharePost(p) {
  const { data } = await supabase.from("ob_follows").select("following:ob_profiles!ob_follows_following_fkey(*)").eq("follower", S.user.id);
  const list = (data || []).map((x) => x.following).filter(Boolean);
  const close = sheet("Enviar para um amigo", ...(list.length ? list.map((u) => h("div", { class: "row", onclick: async () => {
    close(); const { error } = await supabase.from("ob_messages").insert({ from_id: S.user.id, to_id: u.id, kind: "post", post_id: p.id });
    if (error) return toast("Não foi possível enviar", null, "x"); forget("chats"); toast("Enviado para " + u.name, null, "check");
  } }, avatar(u, 42, true), h("b", {}, u.name))) : [h("p", { class: "mut" }, "Siga alguém para poder enviar.")]));
}

async function loadFeed() {
  const [fl, lk] = await Promise.all([supabase.from("ob_follows").select("following").eq("follower", S.user.id), supabase.from("ob_likes").select("post_id").eq("user_id", S.user.id)]);
  const ids = [S.user.id, ...(fl.data || []).map((x) => x.following)];
  const r = await supabase.from("ob_posts").select("*").in("user_id", ids).order("created_at", { ascending: false }).limit(40);
  if (r.error) throw r.error;
  let rows = r.data || [];
  if (rows.length < 3) { const g = await supabase.from("ob_posts").select("*").order("created_at", { ascending: false }).limit(40); if (!g.error && g.data) rows = g.data; }
  return { posts: await hydrate(rows), mine: [...new Set((lk.data || []).map((x) => x.post_id))] };
}

export function feedScreen(page) {
  page.append(topbar(), ...skeletons(2));
  return swr("feed", loadFeed, (d) => {
    const mine = new Set(d.mine);
    put(page, topbar(), d.posts.length ? d.posts.map((p) => postCard(p, mine)) : empty("camera", "Nada por aqui ainda", "Publique a primeira foto ou vídeo.", h("button", { class: "btn", onclick: () => go("/new") }, "Criar publicação")));
  });
}

export function newPostScreen(page) {
  let file = null; const prev = h("div"), cap = h("textarea", { placeholder: "Escreva uma legenda...", rows: 3 }), msg = h("p", { class: "err" });
  const choose = () => pick("image/*,video/*", (f) => {
    file = f; msg.textContent = ""; prev.replaceChildren(h("div", { class: "media", style: "margin-bottom:12px", onclick: choose }, media(f.type.startsWith("video") ? "video" : "image", URL.createObjectURL(f)))); drop.style.display = "none";
  });
  const drop = h("button", { class: "drop", onclick: choose }, icon("image", 34), h("b", { style: "color:var(--tx)" }, "Escolher foto ou vídeo"), h("span", { class: "mut" }, "Toque para abrir a galeria"));
  const btn = h("button", { class: "btn block", onclick: async () => {
    if (!file) return (msg.textContent = "Escolha uma foto ou vídeo.");
    btn.disabled = true; btn.textContent = "Publicando..."; msg.textContent = "";
    try {
      const url = await upload(file, S.user.id);
      const { data, error } = await supabase.from("ob_posts").insert({ user_id: S.user.id, kind: file.type.startsWith("video") ? "video" : "image", url, caption: cap.value.trim() }).select().single();
      if (error) throw error; await hydrate([data]); forget("feed"); toast("Publicado", null, "check"); go("/feed");
    } catch (e) { msg.textContent = e.message || "Não foi possível publicar."; btn.disabled = false; btn.textContent = "Publicar"; }
  } }, "Publicar");
  page.append(h("h2", { class: "title" }, "Nova publicação"), drop, prev, h("div", { class: "field" }, cap), msg, btn);
}

export async function postScreen(page, id) {
  id = decodeURIComponent(id || ""); const bar = backbar("Publicação");
  page.append(bar, ...skeletons(1));
  let p = null, err = null;
  for (let i = 0; i < 3 && !p; i++) {
    const r = await supabase.from("ob_posts").select("*").eq("id", id).maybeSingle(); err = r.error;
    if (r.data) p = (await hydrate([r.data]))[0]; else if (i < 2) await new Promise((ok) => setTimeout(ok, 600));
  }
  if (!p) p = cache.get(id) || null;
  if (!p) return put(page, bar, err ? empty("x", "Não foi possível abrir", err.message || "Verifique sua conexão.", h("button", { class: "btn sm", onclick: () => { page.replaceChildren(); postScreen(page, id); } }, "Tentar de novo")) : empty("x", "Publicação não encontrada", "Ela pode ter sido apagada."));
  const { data: lk } = await supabase.from("ob_likes").select("post_id").eq("user_id", S.user.id).eq("post_id", id);
  const list = h("div"), isOwner = p.user_id === S.user.id;
  const load = async () => {
    const { data } = await supabase.from("ob_comments").select("*").eq("post_id", id).order("created_at");
    list.replaceChildren(...await Promise.all((data || []).map(async (c) => {
      const u = await getProfile(c.user_id);
      return h("div", { class: "cm" }, avatar(u, 34), h("div", { class: "bd" }, h("b", {}, u?.name), c.user_id === p.user_id && h("span", { class: "badge" }, "Autor"), h("span", { class: "mut" }, " " + ago(c.created_at)),
        c.body && h("div", {}, c.body), c.image && h("img", { class: "ci", src: c.image, alt: "" })),
        (isOwner || c.user_id === S.user.id) && h("button", { class: "ib plain danger", "aria-label": "Apagar comentário", onclick: async () => { await supabase.from("ob_comments").delete().eq("id", c.id); load(); } }, icon("trash", 18)));
    })));
  };
  let img = null, busy = false;
  const txt = h("input", { placeholder: "Escreva um comentário...", enterkeyhint: "send", onkeydown: (e) => e.key === "Enter" && send() });
  const clip = h("button", { class: "ib", "aria-label": "Anexar foto", onclick: () => pick("image/*", (f) => { img = f; clip.classList.add("send"); toast("Foto anexada", null, "check"); }) }, icon("camera", 20));
  const send = async () => {
    if (busy || (!txt.value.trim() && !img)) return; busy = true;
    const body = txt.value.trim() || null, file = img; txt.value = ""; img = null; clip.classList.remove("send");
    try {
      const image = file ? await upload(file, S.user.id) : null;
      const { error } = await supabase.from("ob_comments").insert({ post_id: id, user_id: S.user.id, body, image }); if (error) throw error;
      forget("feed"); await load();
    } catch { toast("Não foi possível comentar", null, "x"); txt.value = body || ""; }
    busy = false;
  };
  put(page, bar, postCard(p, new Set((lk || []).map((x) => x.post_id))), h("h3", { style: "margin:4px 2px" }, "Comentários"), list,
    h("div", { class: "pcomp" }, clip, txt, h("button", { class: "ib send", "aria-label": "Enviar", onclick: send }, icon("send", 19))));
  load();
}
