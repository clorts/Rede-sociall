import { supabase } from "./supabase.js";
import { cleanUser } from "./state.js";
import { h, put } from "./ui.js";
import { logoMark } from "./splash.js";

const ERR = [
  [/invalid login/i, "E-mail ou senha incorretos."],
  [/already registered|already been registered/i, "Esse e-mail já tem conta. Toque em Entrar."],
  [/at least 6/i, "A senha precisa ter pelo menos 6 caracteres."],
  [/valid email|invalid email|unable to validate email/i, "Digite um e-mail válido."],
  [/rate limit|too many|security purposes/i, "Muitas tentativas. Espere um pouco e tente de novo."],
  [/not confirmed/i, "Confirme seu e-mail antes de entrar."],
  [/failed to fetch|network/i, "Sem internet. Verifique sua conexão."],
];
const nice = (m = "") => (ERR.find(([r]) => r.test(m)) || [0, m])[1];

export function authScreen(done, notice = "") {
  let signup = false, busy = false; const v = { name: "", user: "", mail: "", pass: "" }, box = h("div", { class: "auth" });
  const draw = () => {
    const field = (key, props) => h("div", { class: "field" }, h("input", { ...props, value: v[key], oninput: (e) => (v[key] = e.target.value) }));
    const msg = h("p", { class: "err" + (notice.startsWith("Conta criada") ? " ok" : "") }, notice), btn = h("button", { class: "btn block", type: "button" }, signup ? "Criar conta" : "Entrar");
    const label = () => (btn.textContent = signup ? "Criar conta" : "Entrar");
    const send = async () => {
      if (busy) return; msg.className = "err"; msg.textContent = "";
      const mail = v.mail.trim(), user = cleanUser(v.user);
      if (!mail || !v.pass) return (msg.textContent = "Preencha e-mail e senha.");
      if (signup && !v.name.trim()) return (msg.textContent = "Digite seu nome.");
      if (signup && user.length < 3) return (msg.textContent = "O @usuário precisa de 3+ caracteres (letras, números, _ ou .).");
      busy = true; btn.disabled = true; btn.textContent = "Aguarde...";
      let r;
      try { r = signup ? await supabase.auth.signUp({ email: mail, password: v.pass, options: { data: { name: v.name.trim(), username: user } } }) : await supabase.auth.signInWithPassword({ email: mail, password: v.pass }); }
      catch (e) { r = { error: e }; }
      busy = false; btn.disabled = false; label();
      if (r.error) msg.textContent = nice(r.error.message);
      else if (!r.data?.session) { signup = false; notice = "Conta criada! Confirme seu e-mail e depois entre."; draw(); }
      else done();
    };
    btn.onclick = send; box.onkeydown = (e) => e.key === "Enter" && e.target.tagName === "INPUT" && send();
    const tab = (target, text) => h("button", { type: "button", class: signup === target ? "on" : "", onclick: () => { if (signup === target) return; signup = target; notice = ""; draw(); } }, text);
    put(box, logoMark(), h("h1", {}, "Orbit"), h("p", { class: "sub" }, signup ? "Crie sua conta em segundos" : "Que bom te ver de volta"),
      h("div", { class: "seg" }, tab(false, "Entrar"), tab(true, "Criar conta")),
      signup && field("name", { placeholder: "Seu nome", autocomplete: "name" }), signup && field("user", { placeholder: "@usuario", autocapitalize: "none", autocomplete: "username" }),
      field("mail", { type: "email", placeholder: "E-mail", autocomplete: "email", inputmode: "email" }), field("pass", { type: "password", placeholder: "Senha (mín. 6)", autocomplete: signup ? "new-password" : "current-password" }), msg, btn);
  };
  draw(); return box;
}
