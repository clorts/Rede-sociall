// Notificações push de verdade (app fechado) via Firebase. Só funciona no APK.
import { supabase } from "./supabase.js";
import { go } from "./ui.js";

let token = null;
const native = () => !!window.Capacitor?.isNativePlatform?.();
export async function initPush() {
  if (!native()) return;
  const P = window.Capacitor.Plugins?.PushNotifications || window.Capacitor.registerPlugin?.("PushNotifications"); if (!P) return;
  try {
    let p = await P.checkPermissions(); if (p.receive !== "granted") p = await P.requestPermissions(); if (p.receive !== "granted") return;
    await P.createChannel?.({ id: "orbit", name: "Mensagens e avisos", importance: 4, visibility: 0, vibration: true, lights: true });
    await P.createChannel?.({ id: "orbit_calls", name: "Chamadas", importance: 5, visibility: 0, vibration: true });
    P.addListener("registration", async (t) => { token = t.value; const { error } = await supabase.rpc("ob_register_push", { p_token: token, p_platform: "android" }); if (error) console.warn("push:", error.message); });
    P.addListener("registrationError", (e) => console.warn("push:", e));
    P.addListener("pushNotificationActionPerformed", (a) => { const u = a.notification?.data?.url; if (u) go(u); });
    await P.register();
  } catch (e) { console.warn("push:", e); }
}
export async function dropPush() { try { if (token) await supabase.rpc("ob_unregister_push", { p_token: token }); } catch {} }
