// Cole aqui a URL e a chave "publishable" do SEU projeto Supabase (nunca a "secret").
export const SUPABASE_URL = "https://gayhznhkwacpuatgljtd.supabase.co";
export const SUPABASE_KEY = "sb_publishable_Hl7NZ8ziL8eFOH9MH3_eWg_ScAE1IFL";
export const APP_NAME = "Orbit";
export const BUCKET = "ob-media";
export const MAX_VIDEO_MB = 50;

// Ligações: quanto tempo a chamada toca antes de virar "não atendida"
export const RING_SECONDS = 45;
// Servidores de conexão das ligações. O TURN abaixo é gratuito e público (bom para testar).
// Para uso sério, crie o seu em metered.ca ou Cloudflare e troque usuário/senha aqui.
export const ICE_SERVERS = [
  { urls: ["stun:stun.l.google.com:19302", "stun:stun1.l.google.com:19302"] },
  { urls: ["turn:openrelay.metered.ca:80", "turn:openrelay.metered.ca:443", "turn:openrelay.metered.ca:443?transport=tcp"], username: "openrelayproject", credential: "openrelayproject" },
];
