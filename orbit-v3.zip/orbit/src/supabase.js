import { SUPABASE_KEY, SUPABASE_URL } from "./config.js";
export let supabase = null;
// Se um servidor de bibliotecas estiver fora do ar, tenta o próximo.
const CDNS = ["https://esm.sh/@supabase/supabase-js@2.45.4", "https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2.45.4/+esm"];
export async function initSupabase() {
  if (supabase) return supabase;
  for (const url of CDNS) {
    try { const lib = await import(url); supabase = lib.createClient(SUPABASE_URL, SUPABASE_KEY, { realtime: { params: { eventsPerSecond: 20 } } }); return supabase; }
    catch (e) { console.warn("Falhou:", url, e); }
  }
  return null;
}
