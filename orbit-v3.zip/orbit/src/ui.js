import { supabase } from "./supabase.js";
import { BUCKET, MAX_VIDEO_MB } from "./config.js";
import { icon } from "./icons.js";
export { icon };

export function h(tag, props = {}, ...kids) {
  const el = document.createElement(tag);
  for (const [k, v] of Object.entries(props || {})) {
    if (k.startsWith("on")) el.addEventListener(k.slice(2), v);
    else if (v === true) el.setAttribute(k, ""); else if (v !== false && v != null) el.setAttribute(k, v);
  }
  el.append(...kids.flat().filter((x) => x != null && x !== false));
  return el;
}
export const go = (p) => { location.hash = "#" + p; };
// replaceChildren que ignora false/null (era isso que fazia aparecer a palavra "false" na tela)
export const put = (el, ...kids) => el.replaceChildren(...kids.flat().filter((x) => x != null && x !== false));
export const fmt = (s) => { s = Math.max(0, Math.round(s)); return Math.floor(s / 60) + ":" + String(s % 60).padStart(2, "0"); };
export const ago = (d) => { const s = (Date.now() - new Date(d)) / 1000; return s < 60 ? "agora" : s < 3600 ? Math.floor(s / 60) + " min" : s < 86400 ? Math.floor(s / 3600) + " h" : Math.floor(s / 86400) + " d"; };
export function toast(msg, onclick, ic = "bell") {
  document.querySelector(".toast")?.remove();
  const t = h("div", { class: "toast", onclick: () => { t.remove(); onclick?.(); } }, icon(ic, 20), h("span", {}, msg));
  document.body.append(t); setTimeout(() => t.remove(), 4000);
}

// Reduz a foto antes de enviar: upload bem mais rápido
export async function compress(file, max = 1600) {
  if (!file.type.startsWith("image/") || file.type === "image/gif") return file;
  try {
    const bmp = await createImageBitmap(file), k = Math.min(1, max / Math.max(bmp.width, bmp.height));
    const c = document.createElement("canvas"); c.width = Math.round(bmp.width * k); c.height = Math.round(bmp.height * k);
    c.getContext("2d").drawImage(bmp, 0, 0, c.width, c.height);
    const blob = await new Promise((r) => c.toBlob(r, "image/jpeg", 0.85));
    return blob ? new File([blob], "img.jpg", { type: "image/jpeg" }) : file;
  } catch { return file; }
}
export async function upload(file, folder, max = 1600) {
  if (file.type.startsWith("video") && file.size > MAX_VIDEO_MB * 1048576) throw new Error("Vídeo maior que " + MAX_VIDEO_MB + " MB");
  file = await compress(file, max);
  const base = (file.type || "").split(";")[0];
  const ext = ((file.name?.includes(".") ? file.name.split(".").pop() : base.split("/")[1]) || "bin").toLowerCase().replace(/[^a-z0-9]/g, "") || "bin";
  const path = `${folder}/${crypto.randomUUID()}.${ext}`;
  const { error } = await supabase.storage.from(BUCKET).upload(path, file, { contentType: base || "application/octet-stream", cacheControl: "31536000" });
  if (error) throw new Error(error.message || "Falha no envio do arquivo");
  return supabase.storage.from(BUCKET).getPublicUrl(path).data.publicUrl;
}

// Cores do avatar (letra do nome)
export const PAL = [["violeta", "#6c5cff", "#c04dff"], ["oceano", "#00b3ff", "#6c5cff"], ["menta", "#00d4a0", "#00a3ff"], ["sol", "#ffb020", "#ff5d73"], ["rosa", "#ff4d9d", "#ff8a5c"], ["lima", "#9be15d", "#00c9a7"], ["noite", "#3a3f7a", "#8e7dff"], ["fogo", "#ff5d3b", "#ffb800"], ["uva", "#8e2de2", "#4a00e0"], ["grafite", "#4b5563", "#9ca3af"]];
export const colorOf = (p) => {
  const k = p?.avatar_color || (p?.id && localStorage.getItem("ob_color_" + p.id)), f = PAL.find((c) => c[0] === k);
  if (f) return f; let n = 0; for (const ch of String(p?.id || p?.name || "")) n = (n * 31 + ch.charCodeAt(0)) >>> 0; return PAL[n % PAL.length];
};
export const avatar = (p, s = 40, ring = false) => {
  const c = colorOf(p), st = `--s:${s}px;--rc:${ring ? c[1] : "transparent"}`;
  return p?.avatar ? h("span", { class: "av" + (ring ? "" : " plain"), style: st }, h("img", { src: p.avatar, alt: "", decoding: "async", loading: "lazy" }))
    : h("span", { class: "av" + (ring ? "" : " plain"), style: `${st};background:linear-gradient(135deg,${c[1]},${c[2]})` }, (p?.name || "?")[0].toUpperCase());
};
export const pick = (accept, cb, capture) => {
  const i = h("input", { type: "file", accept, style: "display:none", capture: capture || false });
  i.onchange = () => { const f = i.files[0]; i.remove(); if (f) cb(f); };
  document.body.append(i); i.click(); setTimeout(() => i.remove(), 120000);
};
export const media = (kind, url) => kind === "video" ? h("video", { src: url, controls: true, playsinline: true, preload: "metadata" }) : kind === "audio" ? h("audio", { src: url, controls: true, preload: "metadata" }) : h("img", { src: url, loading: "lazy", decoding: "async", alt: "" });

export function sheet(title, ...kids) {
  const back = h("div", { class: "sheet-bg", onclick: (e) => e.target === back && close() });
  const close = () => { back.classList.add("out"); setTimeout(() => back.remove(), 200); };
  back.append(h("div", { class: "sheet" }, h("div", { class: "grab" }), title && h("h3", {}, title), ...kids)); document.body.append(back); return close;
}
export const empty = (ic, title, text, btn) => h("div", { class: "empty" }, icon(ic, 30), h("h3", {}, title), h("p", {}, text), btn);
export const skeletons = (n = 2) => Array.from({ length: n }, () => h("div", { class: "post" }, h("div", { class: "hd" }, h("div", { class: "skel", style: "width:40px;height:40px;border-radius:50%" }), h("div", { class: "skel", style: "height:14px;width:140px;border-radius:8px" })), h("div", { class: "skel", style: "aspect-ratio:1;border-radius:22px" })));

// Mostra o que já foi carregado na hora e atualiza em seguida: trocar de aba fica instantâneo
const mem = new Map();
export const forget = (k) => mem.delete(k);
export async function swr(key, fetcher, paint) {
  if (mem.has(key)) await paint(mem.get(key));
  const d = await fetcher(); mem.set(key, d); await paint(d);
}
