// Ligações de voz e vídeo (WebRTC). O "toque" e o fim da chamada passam pela tabela ob_calls
// (segura por RLS, vira notificação push); a conexão em si troca dados por um canal do Realtime.
import { supabase } from "./supabase.js";
import { S, getProfile } from "./state.js";
import { h, avatar, icon, toast, fmt, forget, put } from "./ui.js";
import { ICE_SERVERS, RING_SECONDS } from "./config.js";

let cur = null, starting = false, inbox = null, ringTimer = null, ac = null;
const END = ["declined", "ended", "missed", "canceled"];

/* ---------- sons e vibração ---------- */
function beep(freqs, dur) {
  try {
    ac = ac || new (window.AudioContext || window.webkitAudioContext)(); if (ac.state === "suspended") ac.resume();
    const t = ac.currentTime;
    freqs.forEach((f) => { const o = ac.createOscillator(), g = ac.createGain(); o.frequency.value = f; g.gain.setValueAtTime(0.0001, t); g.gain.exponentialRampToValueAtTime(0.2, t + 0.04); g.gain.exponentialRampToValueAtTime(0.0001, t + dur); o.connect(g).connect(ac.destination); o.start(t); o.stop(t + dur + 0.05); });
  } catch {}
}
function startRing(incoming) {
  stopRing(); const beat = () => { if (incoming) { beep([440, 480], 0.9); navigator.vibrate?.([400, 200, 400]); } else beep([425], 1); };
  beat(); ringTimer = setInterval(beat, incoming ? 2200 : 3000);
}
function stopRing() { clearInterval(ringTimer); ringTimer = null; navigator.vibrate?.(0); }

/* ---------- câmera e microfone ---------- */
const getMedia = (video) => navigator.mediaDevices.getUserMedia({ audio: { echoCancellation: true, noiseSuppression: true, autoGainControl: true }, video: video ? { facingMode: "user", width: { ideal: 640 }, height: { ideal: 480 } } : false });
const permMsg = (e, video) => e?.name === "NotAllowedError" ? `Permita ${video ? "a câmera e o microfone" : "o microfone"} nas permissões do app.` : e?.name === "NotFoundError" ? "Microfone ou câmera não encontrado." : "Não foi possível acessar o microfone/câmera.";
const supported = () => !!(window.RTCPeerConnection && navigator.mediaDevices?.getUserMedia);
const newCall = (o) => ({ pending: [], t0: 0, muted: false, camOff: false, accepted: o.role === "caller", ...o });

/* ---------- tela da chamada ---------- */
function openUI(c) {
  c.v = h("video", { class: "rv", autoplay: true, playsinline: true });
  c.lv = h("video", { class: "lv", autoplay: true, playsinline: true, muted: true });
  c.au = h("audio", { autoplay: true });
  c.st = h("div", { class: "cs" }); c.ctr = h("div", { class: "cctl" });
  c.ui = h("div", { class: "call" + (c.video ? " vid" : "") }, c.v, c.lv, c.au, h("div", { class: "cinfo" }, h("div", { class: "cav" }, avatar(c.peer, 112, true)), h("div", { class: "cn" }, c.peer?.name || "Orbit"), c.st), c.ctr);
  document.body.append(c.ui); controls(c); preview(c);
}
const status = (c, t) => { if (c.st) c.st.textContent = t; };
function preview(c) { if (c.video && c.local) { c.lv.srcObject = c.local; c.lv.classList.add("on"); c.lv.play?.().catch(() => {}); } }
function controls(c) {
  const b = (cls, ic, label, fn) => h("button", { class: "cb " + cls, type: "button", "aria-label": label, onclick: fn }, h("span", { class: "circ" }, icon(ic, 28)), label);
  if (c.role === "callee" && !c.accepted) return put(c.ctr, b("red", "phoneoff", "Recusar", hangup), b("green", c.video ? "video" : "phone", "Atender", accept));
  put(c.ctr,
    b(c.muted ? "off" : "", c.muted ? "micoff" : "mic", c.muted ? "Ativar mic" : "Mudo", () => { c.muted = !c.muted; c.local?.getAudioTracks().forEach((t) => (t.enabled = !c.muted)); controls(c); }),
    c.video && b(c.camOff ? "off" : "", c.camOff ? "videooff" : "video", c.camOff ? "Ligar câmera" : "Câmera", () => { c.camOff = !c.camOff; c.local?.getVideoTracks().forEach((t) => (t.enabled = !c.camOff)); controls(c); }),
    b("red", "phoneoff", "Encerrar", hangup));
}
function attach(c) {
  if (!c.remote) return; const el = c.video ? c.v : c.au;
  if (el.srcObject !== c.remote) { el.srcObject = c.remote; el.play?.().catch(() => {}); }
}

/* ---------- conexão ---------- */
const send = (c, payload) => { try { c.ch?.send({ type: "broadcast", event: "sig", payload }); } catch {} };
function join(c) {
  c.ch = supabase.channel("call-" + c.id, { config: { broadcast: { self: false } } });
  c.ch.on("broadcast", { event: "sig" }, ({ payload }) => onSig(c, payload)).subscribe((s) => { if (s === "SUBSCRIBED") { c.subscribed = true; if (c.role === "callee") send(c, { t: "ready" }); } });
}
function makePc(c) {
  const pc = (c.pc = new RTCPeerConnection({ iceServers: ICE_SERVERS }));
  c.local.getTracks().forEach((t) => pc.addTrack(t, c.local));
  pc.onicecandidate = (e) => e.candidate && send(c, { t: "ice", c: e.candidate.toJSON() });
  pc.ontrack = (e) => { c.remote = e.streams[0] || c.remote || new MediaStream(); if (!e.streams[0]) c.remote.addTrack(e.track); attach(c); };
  pc.onconnectionstatechange = () => {
    if (cur !== c) return; const s = pc.connectionState;
    if (s === "connected") { clearTimeout(c.dc); connected(c); }
    else if (s === "disconnected") { clearTimeout(c.dc); c.dc = setTimeout(() => cur === c && finish("ended", false, "Conexão perdida"), 8000); }
    else if (s === "failed") finish("ended", false, "Não foi possível conectar");
  };
}
const flush = async (c) => { while (c.pending.length) { try { await c.pc.addIceCandidate(c.pending.shift()); } catch {} } };
async function onSig(c, m) {
  if (cur !== c || !m) return;
  try {
    if (m.t === "ready" && c.role === "caller") {
      if (!c.pc) makePc(c);
      if (!c.offered) { c.offered = true; await c.pc.setLocalDescription(await c.pc.createOffer()); }
      send(c, { t: "offer", sdp: c.pc.localDescription });
    } else if (m.t === "offer" && c.role === "callee") {
      if (c.answered) return; c.answered = true; clearInterval(c.readyTimer); makePc(c);
      await c.pc.setRemoteDescription(m.sdp); await flush(c); await c.pc.setLocalDescription(await c.pc.createAnswer()); send(c, { t: "answer", sdp: c.pc.localDescription });
    } else if (m.t === "answer" && c.role === "caller") {
      if (c.pc.signalingState === "have-local-offer") { await c.pc.setRemoteDescription(m.sdp); await flush(c); }
    } else if (m.t === "ice") {
      if (c.pc?.remoteDescription) await c.pc.addIceCandidate(m.c); else c.pending.push(m.c);
    } else if (m.t === "bye") finish(m.st || "ended", true);
  } catch (e) { console.warn("chamada:", e); }
}
function connected(c) {
  if (c.t0) return; c.t0 = Date.now(); stopRing(); clearTimeout(c.timeout); c.ui.classList.add("live"); attach(c);
  status(c, "0:00"); c.tick = setInterval(() => status(c, fmt((Date.now() - c.t0) / 1000)), 1000);
}

/* ---------- fim da chamada ---------- */
function logCall(c, st, secs) {
  const k = c.video ? "vídeo" : "voz";
  const body = secs ? `Chamada de ${k} · ${fmt(secs)}` : st === "declined" ? `Chamada de ${k} recusada` : `Chamada de ${k} não atendida`;
  const row = { from_id: S.user.id, to_id: c.peerId, kind: "call", body }; if (secs) row.read_at = new Date().toISOString();
  supabase.from("ob_messages").insert(row).select().single().then(({ data }) => { forget("chats"); if (data) window.dispatchEvent(new CustomEvent("ob:callmsg", { detail: data })); });
}
function finish(stat, remote = false, note = "") {
  const c = cur; if (!c) return; cur = null;
  [c.timeout, c.dc].forEach(clearTimeout); [c.tick, c.readyTimer].forEach(clearInterval); stopRing();
  const secs = c.t0 ? Math.round((Date.now() - c.t0) / 1000) : 0, st = secs ? "ended" : stat || "missed";
  if (!remote) { send(c, { t: "bye", st }); supabase.from("ob_calls").update({ status: st, ended_at: new Date().toISOString() }).eq("id", c.id).in("status", ["ringing", "accepted"]).then(() => {}); }
  setTimeout(() => c.ch && supabase.removeChannel(c.ch), 500);
  try { c.pc?.close(); } catch {}
  c.local?.getTracks().forEach((t) => t.stop()); c.ui?.remove();
  if (note) toast(note, null, "phone");
  if (c.role === "caller") logCall(c, st, secs);
}
function hangup() { const c = cur; if (c) finish(c.t0 ? "ended" : c.role === "caller" ? "canceled" : "declined"); }

/* ---------- ligar ---------- */
export async function startCall(peerId, video = false) {
  if (cur || starting) return toast("Você já está em uma chamada", null, "phone");
  if (!supported()) return toast("Este aparelho não suporta chamadas", null, "x");
  starting = true;
  try {
    const peer = await getProfile(peerId); let local;
    try { local = await getMedia(video); } catch (e) { return toast(permMsg(e, video), null, "x"); }
    const { data: row, error } = await supabase.from("ob_calls").insert({ caller_id: S.user.id, callee_id: peerId, video, status: "ringing" }).select().single();
    if (error || !row) { local.getTracks().forEach((t) => t.stop()); return toast("Não foi possível ligar. Rode o arquivo 003 no Supabase.", null, "x"); }
    const c = (cur = newCall({ id: row.id, peerId, peer, video, role: "caller", local }));
    openUI(c); status(c, "Chamando…"); startRing(false); join(c);
    c.timeout = setTimeout(() => cur === c && finish("missed"), RING_SECONDS * 1000);
  } finally { starting = false; }
}

/* ---------- receber ---------- */
async function incoming(row) {
  if (row.callee_id !== S.user.id || row.status !== "ringing" || Date.now() - new Date(row.created_at) > (RING_SECONDS + 5) * 1000) return;
  if (cur?.id === row.id) return;
  if (cur || starting) return void supabase.from("ob_calls").update({ status: "declined", ended_at: new Date().toISOString() }).eq("id", row.id).eq("status", "ringing").then(() => {});
  const peer = await getProfile(row.caller_id); if (cur) return;
  const c = (cur = newCall({ id: row.id, peerId: row.caller_id, peer, video: row.video, role: "callee" }));
  openUI(c); status(c, row.video ? "Chamada de vídeo" : "Chamada de voz"); startRing(true);
  c.timeout = setTimeout(() => cur === c && !c.accepted && finish("missed"), RING_SECONDS * 1000);
}
async function accept() {
  const c = cur; if (!c || c.accepted) return; c.accepted = true; stopRing(); clearTimeout(c.timeout); status(c, "Conectando…");
  try { c.local = await getMedia(c.video); } catch (e) { toast(permMsg(e, c.video), null, "x"); c.accepted = false; return finish("declined"); }
  const { data, error } = await supabase.from("ob_calls").update({ status: "accepted", answered_at: new Date().toISOString() }).eq("id", c.id).eq("status", "ringing").select();
  if (cur !== c) return c.local.getTracks().forEach((t) => t.stop());
  if (error || !data?.length) return finish("canceled", true, "A chamada já terminou");
  preview(c); controls(c); join(c);
  c.readyTimer = setInterval(() => c.subscribed && send(c, { t: "ready" }), 1500);
  c.timeout = setTimeout(() => cur === c && !c.t0 && finish("ended", false, "Não foi possível conectar"), 30000);
}
function onRow(row) {
  const c = cur; if (!c || c.id !== row.id) return;
  if (row.status === "accepted" && c.role === "caller" && !c.t0) { stopRing(); status(c, "Conectando…"); clearTimeout(c.timeout); c.timeout = setTimeout(() => cur === c && !c.t0 && finish("ended", false, "Não foi possível conectar"), 30000); }
  else if (END.includes(row.status)) finish(row.status, true);
}
// Chamada que ainda está tocando (ex.: o app foi aberto pela notificação)
export async function checkRinging() {
  const since = new Date(Date.now() - RING_SECONDS * 1000).toISOString();
  const { data } = await supabase.from("ob_calls").select("*").eq("callee_id", S.user.id).eq("status", "ringing").gte("created_at", since).order("created_at", { ascending: false }).limit(1);
  if (data?.[0]) incoming(data[0]);
}
export function initCalls() {
  if (inbox) return; const me = S.user.id, ev = (event, col, fn) => ({ event, schema: "public", table: "ob_calls", filter: `${col}=eq.${me}` });
  inbox = supabase.channel("calls-" + me)
    .on("postgres_changes", ev("INSERT", "callee_id"), (e) => incoming(e.new))
    .on("postgres_changes", ev("UPDATE", "callee_id"), (e) => onRow(e.new))
    .on("postgres_changes", ev("UPDATE", "caller_id"), (e) => onRow(e.new))
    .subscribe();
  checkRinging();
}
