# Orbit — rede social (v3.0)

JavaScript puro + Supabase + Capacitor (APK). Mesma estrutura do City Exchange.

## Passo a passo da atualização (nesta ordem)
1. **Supabase → SQL Editor:** rode `supabase/003_orbit_v3.sql` inteiro (uma vez). Se ainda não rodou, rode antes o `001` e o `002`.
2. **Suba o projeto no GitHub** (substitui o antigo). O Netlify publica sozinho e o GitHub Actions gera o APK novo.
3. **Desinstale o APK antigo e instale o novo.** As permissões de microfone e notificação só entram em um APK novo.
4. Para o **push com o app fechado**, faça a seção "Notificações push" abaixo (é feita uma única vez).

## O que mudou na v3.0
**Correções**
- Apareciam as palavras `false` na tela de login e no perfil. Corrigido.
- Abas Entrar/Criar conta: o toque estava invertido (o botão errado trocava a tela). Corrigido, e o que você digitou não some mais ao trocar.
- "Publicação não encontrada" ao abrir um post recém-publicado. A busca dependia de um cruzamento de tabelas que ficava ambíguo; agora é feita em passos simples, com nova tentativa e mensagem de erro real.
- Áudio: faltava a permissão `MODIFY_AUDIO_SETTINGS` no Android. Agora grava com tempo na tela, cancelar, escolhe o formato certo (Android/iPhone) e mostra o motivo se falhar. Se o aparelho não gravar, abre o seletor de áudio.
- Envio de foto/vídeo/áudio mostra "Enviando…" e avisa quando falha (antes falhava em silêncio).
- Criar conta com @usuário já usado não trava mais; mensagens de erro em português.
- A biblioteca do Supabase tem um segundo servidor de reserva.

**Novo**
- **Ligações de voz e vídeo** (ícones no topo da conversa): toca para quem recebe, atender/recusar, mudo, câmera, tempo de chamada e registro na conversa ("Chamada de voz · 2:13", "não atendida", "recusada"; toque nele para ligar de novo).
- **Mensagens não lidas** com bolinha na aba Conversas e na lista.
- **Notificações reais** (push) para mensagem, foto, áudio, chamada, curtida, comentário e seguidor, mesmo com o app fechado. O toque abre direto a conversa/publicação.
- Curtida e "seguir" repetidos não geram aviso repetido.

## Notificações push (Firebase) — uma vez só
1. Em console.firebase.google.com crie um projeto → **Adicionar app Android** com o nome de pacote `com.orbit.app`.
2. Baixe o `google-services.json` e coloque em `native/google-services.json` (o APK já o usa sozinho).
3. Firebase → Configurações do projeto → **Contas de serviço** → *Gerar nova chave privada* (baixa um `.json`).
4. Supabase → **Edge Functions** → crie a função `send-push`, cole o conteúdo de `supabase/functions/send-push/index.ts` e **desligue "Verify JWT"**.
5. Supabase → Edge Functions → **Secrets**: `FIREBASE_SERVICE_ACCOUNT` = todo o conteúdo do `.json` do passo 3; `PUSH_SECRET` = uma senha inventada por você.
6. SQL Editor: `update ob_config set value = 'A MESMA SENHA DO PUSH_SECRET' where key = 'push_secret';`
7. Gere o APK de novo, instale e abra o app uma vez (aceite a permissão de notificações).

## Ligações — o que saber
- Funciona com o app aberto e, com o push ativo, a chamada também chega como notificação; ao tocar nela o app abre já tocando.
- O servidor TURN em `src/config.js` é gratuito e público: serve para testar. Para muitos usuários, crie o seu (metered.ca ou Cloudflare) e troque lá.
- Uma tela de chamada nativa por cima da tela bloqueada exige código Android próprio (não incluído).

## Pastas
- `src/` telas (feed, chat, perfil, busca, auth, splash) · `src/calls.js` ligações · `src/push.js` push
- `supabase/` banco (001, 002, 003) e `functions/send-push`
- `native/` ícones, chave do Android e (opcional) `google-services.json` · `scripts/` ajuste do Android

## Regras de comentário
Quem comenta pode apagar só o seu; o dono da publicação apaga qualquer um e aparece com o selo **Autor**.

## Testar no PC
`npm run dev` (abre em http://localhost:5173). Em http só funciona em localhost; ligações e áudio precisam de https (Netlify).
