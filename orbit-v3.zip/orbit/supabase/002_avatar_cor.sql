-- Orbit 1.1: cor do avatar (letra do nome). Rode uma vez no SQL Editor do Supabase.
alter table ob_profiles add column if not exists avatar_color text;
