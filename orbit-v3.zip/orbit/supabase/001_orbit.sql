-- Orbit: rode este arquivo inteiro no SQL Editor do Supabase.
create table if not exists ob_profiles (id uuid primary key references auth.users on delete cascade, username text unique not null, name text not null, avatar text, bio text, created_at timestamptz default now());
create table if not exists ob_follows (follower uuid references ob_profiles on delete cascade, following uuid references ob_profiles on delete cascade, primary key (follower, following));
create table if not exists ob_posts (id uuid primary key default gen_random_uuid(), user_id uuid not null references ob_profiles on delete cascade, kind text not null check (kind in ('image','video')), url text not null, caption text, created_at timestamptz default now());
create table if not exists ob_likes (post_id uuid references ob_posts on delete cascade, user_id uuid references ob_profiles on delete cascade, primary key (post_id, user_id));
create table if not exists ob_comments (id uuid primary key default gen_random_uuid(), post_id uuid not null references ob_posts on delete cascade, user_id uuid not null references ob_profiles on delete cascade, body text, image text, created_at timestamptz default now());
create table if not exists ob_messages (id uuid primary key default gen_random_uuid(), from_id uuid not null references ob_profiles on delete cascade, to_id uuid not null references ob_profiles on delete cascade, kind text not null default 'text', body text, url text, post_id uuid references ob_posts on delete set null, created_at timestamptz default now());
create table if not exists ob_notifs (id uuid primary key default gen_random_uuid(), user_id uuid not null references ob_profiles on delete cascade, actor_id uuid not null, type text not null, post_id uuid, created_at timestamptz default now());

alter table ob_profiles enable row level security; alter table ob_follows enable row level security; alter table ob_posts enable row level security;
alter table ob_likes enable row level security; alter table ob_comments enable row level security; alter table ob_messages enable row level security; alter table ob_notifs enable row level security;

create policy "perfis: todos veem" on ob_profiles for select to authenticated using (true);
create policy "perfis: criar o próprio" on ob_profiles for insert to authenticated with check (id = auth.uid());
create policy "perfis: editar o próprio" on ob_profiles for update to authenticated using (id = auth.uid());
create policy "seguir: ver" on ob_follows for select to authenticated using (true);
create policy "seguir: criar" on ob_follows for insert to authenticated with check (follower = auth.uid());
create policy "seguir: apagar" on ob_follows for delete to authenticated using (follower = auth.uid());
create policy "posts: ver" on ob_posts for select to authenticated using (true);
create policy "posts: criar" on ob_posts for insert to authenticated with check (user_id = auth.uid());
create policy "posts: apagar o próprio" on ob_posts for delete to authenticated using (user_id = auth.uid());
create policy "curtidas: ver" on ob_likes for select to authenticated using (true);
create policy "curtidas: criar" on ob_likes for insert to authenticated with check (user_id = auth.uid());
create policy "curtidas: apagar" on ob_likes for delete to authenticated using (user_id = auth.uid());
create policy "comentários: ver" on ob_comments for select to authenticated using (true);
create policy "comentários: criar" on ob_comments for insert to authenticated with check (user_id = auth.uid());
-- o autor apaga o próprio comentário; o dono do post apaga qualquer um
create policy "comentários: apagar" on ob_comments for delete to authenticated using (user_id = auth.uid() or exists (select 1 from ob_posts p where p.id = post_id and p.user_id = auth.uid()));
create policy "msgs: ver as minhas" on ob_messages for select to authenticated using (from_id = auth.uid() or to_id = auth.uid());
create policy "msgs: enviar" on ob_messages for insert to authenticated with check (from_id = auth.uid());
create policy "notifs: ver as minhas" on ob_notifs for select to authenticated using (user_id = auth.uid());
create policy "notifs: apagar as minhas" on ob_notifs for delete to authenticated using (user_id = auth.uid());

-- Notificações automáticas
create or replace function ob_notify() returns trigger language plpgsql security definer set search_path = public as $$
declare dest uuid; begin
  if tg_table_name = 'ob_likes' then select user_id into dest from ob_posts where id = new.post_id; if dest <> new.user_id then insert into ob_notifs(user_id, actor_id, type, post_id) values (dest, new.user_id, 'like', new.post_id); end if;
  elsif tg_table_name = 'ob_comments' then select user_id into dest from ob_posts where id = new.post_id; if dest <> new.user_id then insert into ob_notifs(user_id, actor_id, type, post_id) values (dest, new.user_id, 'comment', new.post_id); end if;
  elsif tg_table_name = 'ob_follows' then insert into ob_notifs(user_id, actor_id, type) values (new.following, new.follower, 'follow');
  elsif tg_table_name = 'ob_messages' then insert into ob_notifs(user_id, actor_id, type) values (new.to_id, new.from_id, 'message'); end if;
  return new; end $$;
create trigger t_like after insert on ob_likes for each row execute function ob_notify();
create trigger t_comment after insert on ob_comments for each row execute function ob_notify();
create trigger t_follow after insert on ob_follows for each row execute function ob_notify();
create trigger t_msg after insert on ob_messages for each row execute function ob_notify();

alter publication supabase_realtime add table ob_messages, ob_notifs;

-- Armazenamento de fotos/vídeos/áudios
insert into storage.buckets (id, name, public) values ('ob-media', 'ob-media', true) on conflict do nothing;
create policy "mídia: ver" on storage.objects for select using (bucket_id = 'ob-media');
create policy "mídia: enviar" on storage.objects for insert to authenticated with check (bucket_id = 'ob-media' and (storage.foldername(name))[1] = auth.uid()::text);
