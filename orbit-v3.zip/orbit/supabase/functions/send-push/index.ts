// Envia o push para o celular via Firebase (FCM v1). Chamada pelo banco a cada aviso novo.
// Segredos necessários (Edge Functions > Secrets): FIREBASE_SERVICE_ACCOUNT e PUSH_SECRET.
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.45.4";

const sa = JSON.parse(Deno.env.get("FIREBASE_SERVICE_ACCOUNT") ?? "{}");
const secret = Deno.env.get("PUSH_SECRET") ?? "";
const db = createClient(Deno.env.get("SUPABASE_URL")!, Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!);

const b64u = (b: ArrayBuffer | string) => {
  const s = typeof b === "string" ? btoa(b) : btoa(String.fromCharCode(...new Uint8Array(b)));
  return s.replace(/=/g, "").replace(/\+/g, "-").replace(/\//g, "_");
};

let cached: { token: string; exp: number } | null = null;
async function accessToken(): Promise<string> {
  if (cached && cached.exp > Date.now() + 60_000) return cached.token;
  const now = Math.floor(Date.now() / 1000);
  const head = b64u(JSON.stringify({ alg: "RS256", typ: "JWT" }));
  const claim = b64u(JSON.stringify({ iss: sa.client_email, scope: "https://www.googleapis.com/auth/firebase.messaging", aud: "https://oauth2.googleapis.com/token", iat: now, exp: now + 3600 }));
  const pem = String(sa.private_key).replace(/-----[A-Z ]+-----/g, "").replace(/\s+/g, "");
  const der = Uint8Array.from(atob(pem), (c) => c.charCodeAt(0));
  const key = await crypto.subtle.importKey("pkcs8", der, { name: "RSASSA-PKCS1-v1_5", hash: "SHA-256" }, false, ["sign"]);
  const sig = await crypto.subtle.sign("RSASSA-PKCS1-v1_5", key, new TextEncoder().encode(`${head}.${claim}`));
  const r = await fetch("https://oauth2.googleapis.com/token", {
    method: "POST", headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body: new URLSearchParams({ grant_type: "urn:ietf:params:oauth:grant-type:jwt-bearer", assertion: `${head}.${claim}.${b64u(sig)}` }),
  });
  const j = await r.json();
  if (!j.access_token) throw new Error("OAuth falhou: " + JSON.stringify(j));
  cached = { token: j.access_token, exp: Date.now() + (j.expires_in ?? 3600) * 1000 };
  return cached.token;
}

Deno.serve(async (req) => {
  if (!secret || req.headers.get("x-push-secret") !== secret) return new Response("forbidden", { status: 403 });
  const n = await req.json();
  const [{ data: tokens }, { data: actor }] = await Promise.all([
    db.from("ob_push_tokens").select("token").eq("user_id", n.user_id),
    db.from("ob_profiles").select("name").eq("id", n.actor_id).maybeSingle(),
  ]);
  if (!tokens?.length) return new Response("sem aparelhos");

  const name = actor?.name ?? "Alguém";
  let title = name, body = n.body ?? "", url = "/dm/" + n.actor_id;
  if (n.type === "like") { title = "Orbit"; body = `${name} curtiu sua publicação`; url = "/post/" + n.post_id; }
  else if (n.type === "comment") { title = "Orbit"; body = `${name} comentou: ${n.body ?? ""}`; url = "/post/" + n.post_id; }
  else if (n.type === "follow") { title = "Orbit"; body = `${name} começou a seguir você`; url = "/user/" + n.actor_id; }
  const call = n.type === "call";

  const access = await accessToken();
  const endpoint = `https://fcm.googleapis.com/v1/projects/${sa.project_id}/messages:send`;
  await Promise.all(tokens.map(async ({ token }: { token: string }) => {
    const r = await fetch(endpoint, {
      method: "POST", headers: { Authorization: `Bearer ${access}`, "Content-Type": "application/json" },
      body: JSON.stringify({ message: {
        token, notification: { title, body }, data: { url, type: String(n.type) },
        android: { priority: "HIGH", ttl: call ? "45s" : "86400s", notification: { channel_id: call ? "orbit_calls" : "orbit", sound: "default", icon: "ic_stat_orbit", color: "#6C5CFF", tag: n.type === "message" ? "msg-" + n.actor_id : undefined } },
      } }),
    });
    if (!r.ok) {
      const t = await r.text(); console.warn("FCM", r.status, t);
      if (/UNREGISTERED|NOT_FOUND/.test(t)) await db.from("ob_push_tokens").delete().eq("token", token);
    }
  }));
  return new Response("ok");
});
