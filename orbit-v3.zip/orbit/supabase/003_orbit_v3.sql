-- Orbit 3.0: ligações, mensagens lidas, notificações push e antispam de avisos.
-- Rode este arquivo inteiro UMA vez no SQL Editor do Supabase (pode rodar de novo sem problema).

-- 1) Ligações de voz e vídeo
create table if not exists ob_calls (
  id uuid primary key default gen_random_uuid(),
  caller_id uuid not null references ob_profiles on delete cascade,
  callee_id uuid not null references ob_profiles on delete cascade,
  video boolean not null default false,
  status text not null default 'ringing' check (status in ('ringing','accepted','declined','missed','canceled','ended')),
  created_at timestamptz default now(), answered_at timestamptz, ended_at timestamptz,
  check (caller_id <> callee_id)
);
create index if not exists ob_calls_callee on ob_calls (callee_id, status, created_at desc);
alter table ob_calls enable row level security;
drop policy if exists "chamadas: ver as minhas" on ob_calls;
create policy "chamadas: ver as minhas" on ob_calls for select to authenticated using (caller_id = auth.uid() or callee_id = auth.uid());
drop policy if exists "chamadas: ligar" on ob_calls;
create policy "chamadas: ligar" on ob_calls for insert to authenticated with check (caller_id = auth.uid());
drop policy if exists "chamadas: atualizar as minhas" on ob_calls;
create policy "chamadas: atualizar as minhas" on ob_calls for update to authenticated using (caller_id = auth.uid() or callee_id = auth.uid()) with check (caller_id = auth.uid() or callee_id = auth.uid());
revoke update on ob_calls from authenticated; grant update (status, answered_at, ended_at) on ob_calls to authenticated;
do $$ begin alter publication supabase_realtime add table ob_calls; exception when duplicate_object then null; end $$;

-- 2) Mensagens lidas (bolinha de não lidas)
alter table ob_messages add column if not exists read_at timestamptz;
create index if not exists ob_messages_unread on ob_messages (to_id, read_at);
drop policy if exists "msgs: marcar como lida" on ob_messages;
create policy "msgs: marcar como lida" on ob_messages for update to authenticated using (to_id = auth.uid()) with check (to_id = auth.uid());
revoke update on ob_messages from authenticated; grant update (read_at) on ob_messages to authenticated;

-- 3) Notificações com texto (prévia da mensagem) e referência
alter table ob_notifs add column if not exists body text;
alter table ob_notifs add column if not exists ref uuid;

-- 4) Aparelhos que recebem push
create table if not exists ob_push_tokens (token text primary key, user_id uuid not null references ob_profiles on delete cascade, platform text default 'android', updated_at timestamptz default now());
alter table ob_push_tokens enable row level security;
drop policy if exists "tokens: ver os meus" on ob_push_tokens;
create policy "tokens: ver os meus" on ob_push_tokens for select to authenticated using (user_id = auth.uid());
create or replace function ob_register_push(p_token text, p_platform text default 'android') returns void language sql security definer set search_path = public as $$
  insert into ob_push_tokens(token, user_id, platform) values (p_token, auth.uid(), p_platform)
  on conflict (token) do update set user_id = auth.uid(), platform = excluded.platform, updated_at = now();
$$;
create or replace function ob_unregister_push(p_token text) returns void language sql security definer set search_path = public as $$
  delete from ob_push_tokens where token = p_token and user_id = auth.uid();
$$;
grant execute on function ob_register_push(text, text), ob_unregister_push(text) to authenticated;

-- 5) Avisos: mensagem com prévia, sem repetir curtida/seguir toda hora, e ligações
create or replace function ob_notify() returns trigger language plpgsql security definer set search_path = public as $$
declare dest uuid; pv text; begin
  if tg_table_name = 'ob_likes' then
    select user_id into dest from ob_posts where id = new.post_id;
    if dest <> new.user_id and not exists (select 1 from ob_notifs where user_id = dest and actor_id = new.user_id and type = 'like' and post_id = new.post_id and created_at > now() - interval '1 day') then
      insert into ob_notifs(user_id, actor_id, type, post_id) values (dest, new.user_id, 'like', new.post_id); end if;
  elsif tg_table_name = 'ob_comments' then
    select user_id into dest from ob_posts where id = new.post_id;
    if dest <> new.user_id then insert into ob_notifs(user_id, actor_id, type, post_id, body) values (dest, new.user_id, 'comment', new.post_id, left(coalesce(new.body, 'Enviou uma foto'), 120)); end if;
  elsif tg_table_name = 'ob_follows' then
    if not exists (select 1 from ob_notifs where user_id = new.following and actor_id = new.follower and type = 'follow' and created_at > now() - interval '1 day') then
      insert into ob_notifs(user_id, actor_id, type) values (new.following, new.follower, 'follow'); end if;
  elsif tg_table_name = 'ob_messages' then
    if new.kind = 'call' then return new; end if;
    pv := case new.kind when 'text' then left(coalesce(new.body, ''), 120) when 'image' then 'Enviou uma foto' when 'video' then 'Enviou um vídeo' when 'audio' then 'Enviou um áudio' when 'post' then 'Enviou uma publicação' else 'Nova mensagem' end;
    insert into ob_notifs(user_id, actor_id, type, body) values (new.to_id, new.from_id, 'message', pv);
  end if;
  return new; end $$;

create or replace function ob_notify_call() returns trigger language plpgsql security definer set search_path = public as $$
begin
  if tg_op = 'INSERT' and new.status = 'ringing' then
    insert into ob_notifs(user_id, actor_id, type, ref, body) values (new.callee_id, new.caller_id, 'call', new.id, case when new.video then 'Chamada de vídeo' else 'Chamada de voz' end);
  elsif tg_op = 'UPDATE' and old.status = 'ringing' and new.status in ('missed', 'canceled') then
    insert into ob_notifs(user_id, actor_id, type, ref, body) values (new.callee_id, new.caller_id, 'missed_call', new.id, case when new.video then 'Chamada de vídeo perdida' else 'Chamada de voz perdida' end);
  end if;
  return new; end $$;
drop trigger if exists t_call_ins on ob_calls; create trigger t_call_ins after insert on ob_calls for each row execute function ob_notify_call();
drop trigger if exists t_call_upd on ob_calls; create trigger t_call_upd after update on ob_calls for each row execute function ob_notify_call();

-- 6) Envio do push: cada aviso novo chama a função "send-push" (veja o README)
create table if not exists ob_config (key text primary key, value text not null);
alter table ob_config enable row level security; -- sem policies: o app nunca lê esta tabela
insert into ob_config(key, value) values
  ('push_url', 'https://gayhznhkwacpuatgljtd.supabase.co/functions/v1/send-push'),
  ('push_secret', 'TROQUE-ESTE-SEGREDO')
on conflict (key) do nothing;
create extension if not exists pg_net;
create or replace function ob_push() returns trigger language plpgsql security definer set search_path = public, extensions as $$
declare u text; s text; begin
  select value into u from ob_config where key = 'push_url'; select value into s from ob_config where key = 'push_secret';
  if u is null or s is null or s = 'TROQUE-ESTE-SEGREDO' then return new; end if;
  perform net.http_post(url := u, headers := jsonb_build_object('Content-Type', 'application/json', 'x-push-secret', s),
    body := jsonb_build_object('user_id', new.user_id, 'actor_id', new.actor_id, 'type', new.type, 'post_id', new.post_id, 'ref', new.ref, 'body', new.body));
  return new;
exception when others then return new; end $$;
drop trigger if exists t_push on ob_notifs; create trigger t_push after insert on ob_notifs for each row execute function ob_push();
