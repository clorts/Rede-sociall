// Cole aqui a URL e a chave "publishable" do SEU projeto Supabase (nunca a "secret").
export const SUPABASE_URL = "https://gayhznhkwacpuatgljtd.supabase.co";
export const SUPABASE_KEY = "sb_publishable_Hl7NZ8ziL8eFOH9MH3_eWg_ScAE1IFL";
export const APP_NAME = "Orbit";
export const BUCKET = "ob-media";
export const MAX_VIDEO_MB = 50;
