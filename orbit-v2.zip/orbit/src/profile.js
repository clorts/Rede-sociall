import { supabase } from "./supabase.js";
import { S, getProfile, dropCache } from "./state.js";
import { h, go, avatar, pick, upload, toast, icon, sheet, empty, PAL, colorOf, forget } from "./ui.js";

const cnt = async (col, v) => (await supabase.from("ob_follows").select("*", { count: "exact", head: true }).eq(col, v)).count || 0;
const relation = async (id) => { const q = (a, b) => supabase.from("ob_follows").select("follower").match({ follower: a, following: b }).maybeSingle(); const [i, he] = await Promise.all([q(S.user.id, id), q(id, S.user.id)]); return { i: !!i.data, he: !!he.data }; };

export async function profileScreen(page, id) {
  const own = id === S.user.id;
  page.append(h("div", { class: "phead" }, h("div", { class: "skel", style: "width:96px;height:96px;border-radius:50%;margin:auto" })));
  const [u, followers, following, posts, rel] = await Promise.all([getProfile(id), cnt("following", id), cnt("follower", id),
    supabase.from("ob_posts").select("*").eq("user_id", id).order("created_at", { ascending: false }).then((r) => r.data || []), own ? null : relation(id)]);
  if (!u) return page.replaceChildren(empty("user", "Perfil não encontrado", "Esse perfil não existe mais."));

  let fcount = followers; const fnum = h("b", {}, String(fcount)), nameEl = h("h2", {}, u.name), bioEl = h("p", { class: "bio" }, u.bio || "");
  let avEl = avatar(u, 96, true); const wrap = h("div", { class: "av-edit" }, avEl, own && h("span", { class: "edit-badge" }, icon("camera", 15)));
  const refresh = () => { const n = avatar(u, 96, true); avEl.replaceWith(n); avEl = n; nameEl.textContent = u.name; bioEl.textContent = u.bio || ""; };
  const save = async (fields) => { Object.assign(u, fields); S.me = u; dropCache(id); forget("feed"); const r = await supabase.from("ob_profiles").update(fields).eq("id", id); return r.error; };

  const setColor = async (k) => { u.avatar_color = k; localStorage.setItem("ob_color_" + id, k); refresh(); const err = await save({ avatar_color: k }); if (err) toast("Cor salva só neste aparelho. Rode o arquivo 002 no Supabase.", null, "palette"); };
  const setPhoto = (done) => pick("image/*", async (f) => {
    const old = u.avatar; u.avatar = URL.createObjectURL(f); refresh(); done?.();
    try { const url = await upload(f, S.user.id, 512); u.avatar = url; const err = await save({ avatar: url }); if (err) throw err; toast("Foto atualizada", null, "check"); }
    catch (e) { u.avatar = old; refresh(); toast("Não foi possível enviar a foto", null, "x"); }
  });
  const avatarSheet = () => {
    const prev = h("div", { style: "text-align:center" }), sw = h("div", { class: "sw" });
    const paint = () => { prev.replaceChildren(avatar(u, 88, true)); sw.replaceChildren(...PAL.map((c) => h("button", { "aria-label": c[0], class: colorOf(u)[0] === c[0] ? "on" : "", style: `background:linear-gradient(135deg,${c[1]},${c[2]})`, onclick: async () => { await setColor(c[0]); paint(); } }, colorOf(u)[0] === c[0] && icon("check", 20)))); };
    paint(); const close = sheet("Foto de perfil", prev, h("p", { class: "mut", style: "margin:14px 0 0" }, "Cor da letra"), sw,
      h("button", { class: "btn block", onclick: () => setPhoto(close) }, icon("camera", 18), "Trocar foto"),
      u.avatar && h("button", { class: "btn ghost block", onclick: async () => { u.avatar = null; refresh(); paint(); await save({ avatar: null }); toast("Foto removida", null, "check"); } }, "Remover foto"));
  };
  const editSheet = () => {
    const name = h("input", { value: u.name, placeholder: "Nome", maxlength: 40 }), bio = h("input", { value: u.bio || "", placeholder: "Bio", maxlength: 120 });
    const close = sheet("Editar perfil", h("div", { class: "field" }, name), h("div", { class: "field" }, bio), h("button", { class: "btn block", onclick: async () => { close(); await save({ name: name.value.trim() || u.name, bio: bio.value.trim() }); refresh(); toast("Perfil salvo", null, "check"); } }, "Salvar"));
  };
  if (own) wrap.onclick = avatarSheet;

  const fb = h("button", { class: "btn sm" }); const paintF = () => { fb.textContent = rel.i ? "Seguindo" : rel.he ? "Seguir de volta" : "Seguir"; fb.className = "btn sm" + (rel.i ? " ghost" : ""); };
  if (!own) { paintF(); fb.onclick = async () => { rel.i = !rel.i; fcount += rel.i ? 1 : -1; fnum.textContent = fcount; paintF(); forget("feed"); if (rel.i) await supabase.from("ob_follows").insert({ follower: S.user.id, following: id }); else await supabase.from("ob_follows").delete().match({ follower: S.user.id, following: id }); }; }

  page.replaceChildren(!own && h("header", { class: "top" }, h("button", { class: "ib", "aria-label": "Voltar", onclick: () => history.back() }, icon("back", 20))),
    h("div", { class: "phead", style: own ? "padding-top:24px" : "" }, wrap, nameEl, h("div", { class: "mut" }, "@" + u.username), bioEl,
      h("div", { class: "stats" }, h("div", {}, fnum, h("span", {}, "seguidores")), h("div", {}, h("b", {}, String(following)), h("span", {}, "seguindo")), h("div", {}, h("b", {}, String(posts.length)), h("span", {}, "posts"))),
      h("div", { class: "pact" }, own ? [h("button", { class: "btn ghost sm", onclick: editSheet }, icon("edit", 16), "Editar perfil"), h("button", { class: "ib", "aria-label": "Sair", onclick: () => supabase.auth.signOut() }, icon("logout", 19))]
        : [fb, h("button", { class: "btn ghost sm", onclick: () => go("/dm/" + id) }, icon("chat", 16), "Mensagem")])),
    posts.length ? h("div", { class: "grid" }, posts.map((p) => h("div", { class: "cell", onclick: () => go("/post/" + p.id) }, p.kind === "video" ? [h("video", { src: p.url + "#t=0.1", preload: "metadata", muted: true, playsinline: true }), icon("film", 18)] : h("img", { src: p.url, loading: "lazy", decoding: "async", alt: "" }))))
      : empty("camera", own ? "Sua galeria está vazia" : "Sem publicações", own ? "Compartilhe sua primeira foto." : "Esta pessoa ainda não publicou.", own && h("button", { class: "btn", onclick: () => go("/new") }, "Publicar agora")));
}
