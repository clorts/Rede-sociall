import { initSupabase, supabase } from "./supabase.js";
import { S, loadMe, getProfile } from "./state.js";
import { h, go, toast, icon, empty } from "./ui.js";
import { splash } from "./splash.js";
import { authScreen } from "./auth.js";
import { feedScreen, newPostScreen, postScreen } from "./feed.js";
import { searchScreen } from "./search.js";
import { chatsScreen, roomScreen } from "./chat.js";
import { profileScreen } from "./profile.js";

const routes = { feed: feedScreen, search: searchScreen, chats: chatsScreen, new: newPostScreen, me: (v) => profileScreen(v, S.user.id), user: profileScreen, post: postScreen, dm: (v, a) => roomScreen(v, "dm", a) };
const TABS = [["feed", "Início", "home"], ["search", "Buscar", "search"], ["new", "Postar", "plus"], ["chats", "Conversas", "chat"], ["me", "Perfil", "user"]];
let view, appEl, ind, cleanup = null, token = 0, started = false;

async function render() {
  if (!started) return; cleanup?.(); cleanup = null; const my = ++token;
  const [seg, arg] = (location.hash.replace(/^#\/?/, "") || "feed").split("/"); const name = routes[seg] ? seg : "feed";
  appEl.classList.toggle("notabs", ["dm", "post"].includes(name));
  const i = TABS.findIndex((t) => t[0] === name); ind.style.opacity = i < 0 || name === "new" ? 0 : 1; if (i >= 0) ind.style.transform = `translateX(${i * 100}%)`;
  appEl.querySelectorAll(".tab").forEach((t) => t.classList.toggle("on", t.dataset.r === name));
  const page = h("div", { class: "page" }); view.classList.toggle("flush", name === "dm"); view.replaceChildren(page); view.scrollTop = 0;
  try { const c = await routes[name](page, arg); if (my !== token) c?.(); else cleanup = c || null; }
  catch (e) { console.error(e); page.replaceChildren(empty("x", "Algo deu errado", "Verifique sua conexão e tente de novo.", h("button", { class: "btn sm", onclick: render }, "Tentar de novo"))); }
}

function notifications() {
  if ("Notification" in window && Notification.permission === "default") Notification.requestPermission();
  const text = { like: "curtiu sua publicação", comment: "comentou na sua publicação", follow: "começou a seguir você", message: "enviou uma mensagem" };
  supabase.channel("notifs").on("postgres_changes", { event: "INSERT", schema: "public", table: "ob_notifs", filter: "user_id=eq." + S.user.id }, async (e) => {
    const a = await getProfile(e.new.actor_id), msg = `${a?.name} ${text[e.new.type] || ""}`;
    const dest = e.new.type === "message" ? "/dm/" + e.new.actor_id : e.new.post_id ? "/post/" + e.new.post_id : "/user/" + e.new.actor_id;
    toast(msg, () => go(dest)); try { if (Notification.permission === "granted" && document.hidden) new Notification("Orbit", { body: msg, icon: "/src/assets/icon.png" }); } catch {}
  }).subscribe();
}

function startApp() {
  document.body.replaceChildren(); view = h("main", { id: "view" }); ind = h("div", { class: "ind" });
  appEl = h("div", { id: "app" }, view, h("nav", { class: "tabs" }, ind, TABS.map(([r, l, i]) => h("button", { class: "tab" + (r === "new" ? " fab" : ""), "data-r": r, "aria-label": l, onclick: () => { if (location.hash === "#/" + r) view.scrollTo({ top: 0, behavior: "smooth" }); else go("/" + r); } }, icon(i, 22), h("span", { class: "l" }, l)))));
  document.body.append(appEl); started = true; window.addEventListener("hashchange", render);
  notifications(); if (!location.hash) location.hash = "#/feed"; else render();
}

async function boot(notice = "") {
  document.body.replaceChildren(); const sp = splash(); await initSupabase();
  const session = supabase ? (await supabase.auth.getSession()).data?.session : null; await sp;
  const show = (el) => document.body.replaceChildren(h("div", { id: "app" }, h("main", { id: "view" }, el)));
  if (!supabase) return show(empty("x", "Sem conexão", "Não foi possível conectar ao Orbit.", h("button", { class: "btn sm", onclick: () => boot() }, "Tentar de novo")));
  supabase.auth.onAuthStateChange((ev) => { if (ev === "SIGNED_OUT") location.reload(); });
  if (!session) return show(authScreen(() => boot(), notice));
  S.user = session.user; S.me = await loadMe(session.user);
  if (!S.me) return show(authScreen(() => boot(), "Rode o SQL do Supabase (veja o README)."));
  startApp();
}
boot();
