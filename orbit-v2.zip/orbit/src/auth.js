import { supabase } from "./supabase.js";
import { h } from "./ui.js";
import { logoMark } from "./splash.js";
export function authScreen(done, notice = "") {
  let signup = false; const box = h("div", { class: "auth" });
  const draw = () => {
    const name = h("input", { placeholder: "Seu nome", autocomplete: "name" }), user = h("input", { placeholder: "@usuario", autocapitalize: "none" });
    const mail = h("input", { type: "email", placeholder: "E-mail", autocomplete: "email" }), pass = h("input", { type: "password", placeholder: "Senha (mín. 6)", autocomplete: signup ? "new-password" : "current-password" });
    const msg = h("p", { class: "err" }, notice), btn = h("button", { class: "btn block" }, signup ? "Criar conta" : "Entrar");
    const send = async () => {
      msg.textContent = ""; btn.disabled = true; btn.textContent = "Aguarde...";
      const r = signup ? await supabase.auth.signUp({ email: mail.value.trim(), password: pass.value, options: { data: { name: name.value.trim(), username: user.value.trim().replace("@", "") } } }) : await supabase.auth.signInWithPassword({ email: mail.value.trim(), password: pass.value });
      btn.disabled = false; btn.textContent = signup ? "Criar conta" : "Entrar";
      if (r.error) msg.textContent = r.error.message; else if (!r.data.session) msg.textContent = "Confirme seu e-mail e depois entre."; else done();
    };
    btn.onclick = send; box.onkeydown = (e) => e.key === "Enter" && send();
    const tab = (on, label) => h("button", { class: on ? "on" : "", onclick: () => { if (signup !== !on) return; signup = !signup; notice = ""; draw(); } }, label);
    box.replaceChildren(logoMark(), h("h1", {}, "Orbit"), h("p", { class: "sub" }, signup ? "Crie sua conta em segundos" : "Que bom te ver de volta"),
      h("div", { class: "seg" }, tab(!signup, "Entrar"), tab(signup, "Criar conta")),
      signup && h("div", { class: "field" }, name), signup && h("div", { class: "field" }, user), h("div", { class: "field" }, mail), h("div", { class: "field" }, pass), msg, btn);
  };
  draw(); return box;
}
