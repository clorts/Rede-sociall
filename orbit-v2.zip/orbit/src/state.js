import { supabase } from "./supabase.js";
export const S = { user: null, me: null };
const cache = new Map();
export async function getProfile(id) {
  if (cache.has(id)) return cache.get(id);
  const { data } = await supabase.from("ob_profiles").select("*").eq("id", id).maybeSingle();
  if (data) cache.set(id, data); return data;
}
export const dropCache = (id) => cache.delete(id);
export async function loadMe(user) {
  let { data } = await supabase.from("ob_profiles").select("*").eq("id", user.id).maybeSingle();
  if (!data) {
    const m = user.user_metadata || {};
    const u = (m.username || user.email.split("@")[0]).toLowerCase().replace(/[^a-z0-9_.]/g, "").slice(0, 20) || "user" + Math.floor(Math.random() * 9999);
    data = (await supabase.from("ob_profiles").insert({ id: user.id, username: u, name: m.name || u }).select().single()).data;
  }
  return data;
}
