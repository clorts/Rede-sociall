import { supabase } from "./supabase.js";
import { S, getProfile } from "./state.js";
import { h, go, ago, avatar, media, pick, upload, icon, empty, swr, forget } from "./ui.js";

export function chatsScreen(page) {
  page.append(h("h2", { class: "title" }, "Conversas"), ...[1, 2, 3].map(() => h("div", { class: "skel", style: "height:62px;border-radius:18px;margin-bottom:10px" })));
  return swr("chats", async () => {
    const { data } = await supabase.from("ob_messages").select("*").or(`from_id.eq.${S.user.id},to_id.eq.${S.user.id}`).order("created_at", { ascending: false }).limit(300);
    const seen = new Map(); (data || []).forEach((m) => { const o = m.from_id === S.user.id ? m.to_id : m.from_id; if (!seen.has(o)) seen.set(o, m); });
    return Promise.all([...seen].map(async ([o, m]) => ({ o, m, u: await getProfile(o) })));
  }, (rows) => page.replaceChildren(h("h2", { class: "title" }, "Conversas"), ...(rows.length ? rows.map(({ o, m, u }) => h("div", { class: "row", onclick: () => go("/dm/" + o) }, avatar(u, 50, true), h("div", { class: "grow" }, h("b", {}, u?.name), h("div", { class: "mut", style: "white-space:nowrap;overflow:hidden;text-overflow:ellipsis" }, (m.from_id === S.user.id ? "Você: " : "") + (m.body || ({ post: "Publicação", image: "Foto", video: "Vídeo", audio: "Áudio" })[m.kind] || ""))), h("span", { class: "mut" }, ago(m.created_at)))) : [empty("chat", "Nenhuma conversa ainda", "Busque alguém e mande a primeira mensagem.", h("button", { class: "btn", onclick: () => go("/search") }, "Buscar pessoas"))])));
}

export async function roomScreen(page, _k, peer) {
  const u = await getProfile(peer), box = h("div", { class: "msgs" }), me = S.user.id;
  const bgKey = "ob_bg_" + peer, setBg = (url) => { box.style.backgroundImage = url ? `url(${url})` : ""; }; setBg(localStorage.getItem(bgKey));
  const bubble = async (m) => {
    let body = [m.body];
    if (m.kind === "post") { const { data: p } = await supabase.from("ob_posts").select("*").eq("id", m.post_id).maybeSingle(); body = p ? [h("div", { onclick: () => go("/post/" + p.id) }, media(p.kind, p.url), h("small", {}, "Ver publicação"))] : ["Publicação removida"]; }
    else if (m.url) body = [media(m.kind, m.url), m.body];
    return h("div", { class: "m" + (m.from_id === me ? " me" : "") }, body, h("span", { class: "t" }, new Date(m.created_at).toLocaleTimeString("pt-BR", { hour: "2-digit", minute: "2-digit" })));
  };
  const add = async (m) => { box.append(await bubble(m)); box.scrollTop = box.scrollHeight; };
  const sendBtn = h("button", { class: "ib send", "aria-label": "Enviar", onclick: () => submit() }, icon("send", 19));
  const mic = h("button", { class: "ib", "aria-label": "Gravar áudio" }, icon("mic", 20));
  const txt = h("input", { placeholder: "Mensagem...", onkeydown: (e) => e.key === "Enter" && submit() });
  page.append(h("div", { class: "chathd" }, h("button", { class: "ib plain", "aria-label": "Voltar", onclick: () => history.back() }, icon("back", 22)), h("div", { style: "display:flex;gap:10px;align-items:center;flex:1;min-width:0", onclick: () => go("/user/" + peer) }, avatar(u, 38, true), h("b", {}, u?.name)),
    h("button", { class: "ib", "aria-label": "Fundo da conversa", onclick: () => pick("image/*", async (f) => { const url = await upload(f, me, 1200); localStorage.setItem(bgKey, url); setBg(url); }) }, icon("image", 20))),
    box, h("div", { class: "composer" }, h("button", { class: "ib", "aria-label": "Anexar", onclick: () => pick("image/*,video/*", async (f) => send({ kind: f.type.startsWith("video") ? "video" : "image", url: await upload(f, me) })) }, icon("clip", 20)), txt, mic, sendBtn));
  const { data } = await supabase.from("ob_messages").select("*").or(`and(from_id.eq.${me},to_id.eq.${peer}),and(from_id.eq.${peer},to_id.eq.${me})`).order("created_at").limit(200);
  box.append(...await Promise.all((data || []).map(bubble))); box.scrollTop = box.scrollHeight;
  const ch = supabase.channel("dm-" + me + "-" + peer).on("postgres_changes", { event: "INSERT", schema: "public", table: "ob_messages", filter: "to_id=eq." + me }, (e) => e.new.from_id === peer && add(e.new)).subscribe();
  const send = async (row) => { const { data: m } = await supabase.from("ob_messages").insert({ from_id: me, to_id: peer, ...row }).select().single(); forget("chats"); m && add(m); };
  const submit = () => { if (txt.value.trim()) { send({ kind: "text", body: txt.value.trim() }); txt.value = ""; } };
  let rec = null, chunks = [];
  mic.onclick = async () => {
    if (rec) { rec.stop(); return; }
    try { const st = await navigator.mediaDevices.getUserMedia({ audio: true }); rec = new MediaRecorder(st); chunks = []; rec.ondataavailable = (e) => chunks.push(e.data);
      rec.onstop = async () => { st.getTracks().forEach((t) => t.stop()); const f = new File(chunks, "audio.webm", { type: "audio/webm" }); rec = null; mic.classList.remove("rec"); mic.replaceChildren(icon("mic", 20)); send({ kind: "audio", url: await upload(f, me) }); };
      rec.start(); mic.classList.add("rec"); mic.replaceChildren(icon("stop", 20)); } catch { alert("Permita o microfone."); }
  };
  return () => supabase.removeChannel(ch);
}
