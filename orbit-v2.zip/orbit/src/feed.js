import { supabase } from "./supabase.js";
import { S, getProfile } from "./state.js";
import { h, go, ago, avatar, media, pick, upload, toast, icon, sheet, empty, skeletons, swr, forget } from "./ui.js";

const SEL = "*, author:ob_profiles(*), likes:ob_likes(count), comms:ob_comments(count)";
const topbar = () => h("header", { class: "top" }, h("img", { src: "/src/assets/icon.png", alt: "" }), h("span", { class: "word" }, "Orbit"));

export function postCard(p, mine = new Set()) {
  let liked = mine.has(p.id), n = p.likes?.[0]?.count || 0, last = 0;
  const cnt = h("span"), lb = h("button", { class: "act", "aria-label": "Curtir" }, icon("heart", 22), cnt), burst = h("div", { class: "burst" }, icon("heart", 88));
  const paint = () => { lb.classList.toggle("on", liked); cnt.textContent = n || ""; }; paint();
  const toggle = async () => {
    liked = !liked; n += liked ? 1 : -1; paint();
    if (liked) { lb.classList.remove("pop"); void lb.offsetWidth; lb.classList.add("pop"); }
    const r = liked ? await supabase.from("ob_likes").insert({ post_id: p.id, user_id: S.user.id }) : await supabase.from("ob_likes").delete().match({ post_id: p.id, user_id: S.user.id });
    if (r.error) { liked = !liked; n += liked ? 1 : -1; paint(); toast("Não foi possível curtir", null, "x"); }
  };
  lb.onclick = toggle;
  const m = h("div", { class: "media", onclick: (e) => {
    if (e.target.closest("video,audio")) return; const t = Date.now();
    if (t - last < 300) { burst.classList.remove("go"); void burst.offsetWidth; burst.classList.add("go"); if (!liked) toggle(); } last = t;
  } }, media(p.kind, p.url), burst);
  const card = h("article", { class: "post" },
    h("div", { class: "hd" }, h("div", { style: "display:flex;gap:11px;align-items:center;flex:1;min-width:0", onclick: () => go("/user/" + p.user_id) }, avatar(p.author, 42, true), h("div", { class: "grow" }, h("b", {}, p.author?.name), h("div", { class: "mut" }, "@" + p.author?.username + " · " + ago(p.created_at)))),
      p.user_id === S.user.id && h("button", { class: "ib plain danger", "aria-label": "Apagar", onclick: () => {
        const close = sheet("Apagar publicação?", h("p", { class: "mut" }, "Essa ação não pode ser desfeita."), h("button", { class: "btn block", onclick: async () => { close(); await supabase.from("ob_posts").delete().eq("id", p.id); forget("feed"); card.remove(); toast("Publicação apagada", null, "check"); } }, "Apagar"), h("button", { class: "btn ghost block", onclick: () => close() }, "Cancelar"));
      } }, icon("trash", 20))),
    m, h("div", { class: "acts" }, lb, h("button", { class: "act", "aria-label": "Comentários", onclick: () => go("/post/" + p.id) }, icon("chat", 22), h("span", {}, p.comms?.[0]?.count || "")), h("button", { class: "act", "aria-label": "Enviar", onclick: () => sharePost(p) }, icon("send", 21))),
    p.caption && h("p", { class: "cap" }, h("b", {}, p.author?.name + " "), p.caption));
  return card;
}

async function sharePost(p) {
  const { data } = await supabase.from("ob_follows").select("following:ob_profiles!ob_follows_following_fkey(*)").eq("follower", S.user.id);
  const list = (data || []).map((x) => x.following).filter(Boolean);
  const close = sheet("Enviar para um amigo", ...(list.length ? list.map((u) => h("div", { class: "row", onclick: async () => { close(); await supabase.from("ob_messages").insert({ from_id: S.user.id, to_id: u.id, kind: "post", post_id: p.id }); forget("chats"); toast("Enviado para " + u.name, null, "check"); } }, avatar(u, 42, true), h("b", {}, u.name))) : [h("p", { class: "mut" }, "Siga alguém para poder enviar.")]));
}

async function loadFeed() {
  const [{ data: fl }, { data: lk }] = await Promise.all([supabase.from("ob_follows").select("following").eq("follower", S.user.id), supabase.from("ob_likes").select("post_id").eq("user_id", S.user.id)]);
  const ids = [S.user.id, ...(fl || []).map((x) => x.following)];
  let { data: posts } = await supabase.from("ob_posts").select(SEL).in("user_id", ids).order("created_at", { ascending: false }).limit(40);
  if (!posts?.length || posts.length < 3) posts = (await supabase.from("ob_posts").select(SEL).order("created_at", { ascending: false }).limit(40)).data;
  return { posts: posts || [], mine: [...new Set((lk || []).map((x) => x.post_id))] };
}

export function feedScreen(page) {
  page.append(topbar(), ...skeletons(2));
  return swr("feed", loadFeed, (d) => {
    const mine = new Set(d.mine);
    page.replaceChildren(topbar(), ...(d.posts.length ? d.posts.map((p) => postCard(p, mine)) : [empty("camera", "Nada por aqui ainda", "Publique a primeira foto ou vídeo.", h("button", { class: "btn", onclick: () => go("/new") }, "Criar publicação"))]));
  });
}

export function newPostScreen(page) {
  let file = null; const prev = h("div"), cap = h("textarea", { placeholder: "Escreva uma legenda...", rows: 3 }), msg = h("p", { class: "err" });
  const choose = () => pick("image/*,video/*", (f) => { file = f; prev.replaceChildren(h("div", { class: "media", style: "margin-bottom:12px" }, media(f.type.startsWith("video") ? "video" : "image", URL.createObjectURL(f)))); drop.style.display = "none"; });
  const drop = h("button", { class: "drop", onclick: choose }, icon("image", 34), h("b", { style: "color:var(--tx)" }, "Escolher foto ou vídeo"), h("span", { class: "mut" }, "Toque para abrir a galeria"));
  const btn = h("button", { class: "btn block", onclick: async () => {
    if (!file) return (msg.textContent = "Escolha uma foto ou vídeo.");
    btn.disabled = true; btn.textContent = "Publicando..."; msg.textContent = "";
    try { const url = await upload(file, S.user.id); const { error } = await supabase.from("ob_posts").insert({ user_id: S.user.id, kind: file.type.startsWith("video") ? "video" : "image", url, caption: cap.value.trim() }); if (error) throw error; forget("feed"); toast("Publicado", null, "check"); go("/feed"); }
    catch (e) { msg.textContent = e.message; btn.disabled = false; btn.textContent = "Publicar"; }
  } }, "Publicar");
  page.append(h("h2", { class: "title" }, "Nova publicação"), drop, prev, h("div", { class: "field" }, cap), msg, btn);
}

export async function postScreen(page, id) {
  const [{ data: p }, { data: lk }] = await Promise.all([supabase.from("ob_posts").select(SEL).eq("id", id).maybeSingle(), supabase.from("ob_likes").select("post_id").eq("user_id", S.user.id).eq("post_id", id)]);
  if (!p) return page.append(empty("x", "Publicação não encontrada", "Ela pode ter sido apagada."));
  const list = h("div"), isOwner = p.user_id === S.user.id;
  const load = async () => {
    const { data } = await supabase.from("ob_comments").select("*").eq("post_id", id).order("created_at");
    list.replaceChildren(...await Promise.all((data || []).map(async (c) => {
      const u = await getProfile(c.user_id);
      return h("div", { class: "cm" }, avatar(u, 34), h("div", { class: "bd" }, h("b", {}, u?.name), c.user_id === p.user_id && h("span", { class: "badge" }, "Autor"), h("span", { class: "mut" }, " " + ago(c.created_at)),
        c.body && h("div", {}, c.body), c.image && h("img", { class: "ci", src: c.image, alt: "" })),
        (isOwner || c.user_id === S.user.id) && h("button", { class: "ib plain danger", "aria-label": "Apagar comentário", onclick: async () => { await supabase.from("ob_comments").delete().eq("id", c.id); load(); } }, icon("trash", 18)));
    })));
  };
  let img = null; const txt = h("input", { placeholder: "Escreva um comentário...", onkeydown: (e) => e.key === "Enter" && send() }), clip = h("button", { class: "ib", "aria-label": "Anexar foto", onclick: () => pick("image/*", (f) => { img = f; clip.classList.add("send"); toast("Foto anexada", null, "check"); }) }, icon("camera", 20));
  const send = async () => {
    if (!txt.value.trim() && !img) return; const body = txt.value.trim() || null; txt.value = "";
    let image = null; if (img) image = await upload(img, S.user.id); img = null; clip.classList.remove("send");
    await supabase.from("ob_comments").insert({ post_id: id, user_id: S.user.id, body, image }); forget("feed"); load();
  };
  page.append(h("header", { class: "top" }, h("button", { class: "ib", "aria-label": "Voltar", onclick: () => history.back() }, icon("back", 20)), h("span", { class: "word", style: "font-size:20px" }, "Publicação")),
    postCard(p, new Set((lk || []).map((x) => x.post_id))), h("h3", { style: "margin:4px 2px" }, "Comentários"), list,
    h("div", { class: "pcomp" }, clip, txt, h("button", { class: "ib send", "aria-label": "Enviar", onclick: send }, icon("send", 19))));
  load();
}
