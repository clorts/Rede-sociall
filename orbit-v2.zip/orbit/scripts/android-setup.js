// Roda depois de "npx cap add android": permissões, ícone do app e chave fixa de assinatura
// (para o APK novo instalar por cima do antigo).
import { copyFileSync, existsSync, mkdirSync, readFileSync, readdirSync, writeFileSync } from "node:fs";
import { homedir } from "node:os";
import { join } from "node:path";

const manifestPath = join("android", "app", "src", "main", "AndroidManifest.xml");
if (!existsSync(manifestPath)) throw new Error("Rode 'npx cap add android' antes deste script.");

const permissions = [
  "android.permission.INTERNET",
  "android.permission.ACCESS_NETWORK_STATE",
  "android.permission.CAMERA",
  "android.permission.RECORD_AUDIO",
  "android.permission.READ_MEDIA_IMAGES",
  "android.permission.READ_MEDIA_VIDEO",
];
let manifest = readFileSync(manifestPath, "utf8");
const missing = permissions.filter((p) => !manifest.includes(`"${p}"`));
if (missing.length > 0) {
  const lines = missing.map((p) => `    <uses-permission android:name="${p}" />`).join("\n");
  manifest = manifest.replace("<application", `${lines}\n\n    <application`);
  writeFileSync(manifestPath, manifest);
}

// Ícone do app
const resDir = join("android", "app", "src", "main", "res");
if (existsSync(join("native", "res"))) {
  for (const d of readdirSync(join("native", "res"))) {
    mkdirSync(join(resDir, d), { recursive: true });
    for (const f of readdirSync(join("native", "res", d))) copyFileSync(join("native", "res", d, f), join(resDir, d, f));
  }
  const valuesDir = join(resDir, "values");
  mkdirSync(valuesDir, { recursive: true });
  writeFileSync(join(valuesDir, "ic_launcher_background.xml"), '<?xml version="1.0" encoding="utf-8"?>\n<resources>\n    <color name="ic_launcher_background">#5B4BFF</color>\n</resources>\n');
}

// Chave de assinatura fixa
const keystore = join("native", "debug.keystore");
if (existsSync(keystore)) {
  const dir = join(homedir(), ".android");
  mkdirSync(dir, { recursive: true });
  copyFileSync(keystore, join(dir, "debug.keystore"));
}
console.log("Android configurado");
